<?php
require_once INCLUDES_PATH . '/auth.php';
Auth::logout();
header("Location: " . SITE_URL . "/login");
exit();
?>
