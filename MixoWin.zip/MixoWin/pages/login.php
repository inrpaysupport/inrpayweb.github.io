<?php
$page_title = 'Login';
$current_page = 'login';
$extra_css = ['login.css'];

require_once INCLUDES_PATH . '/header.php';

// Check if already logged in
if (Auth::isLoggedIn()) {
    header("Location: " . SITE_URL . "/profile");
    exit();
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error = 'Please fill in all fields.';
    } else {
        $result = Auth::login($username, $password);
        if ($result['success']) {
            header("Location: " . SITE_URL . "/profile");
            exit();
        } else {
            $error = $result['message'];
        }
    }
}
?>

<section class="auth-section">
    <div class="auth-container glass-card animate-fade-in">
        <div class="auth-header">
            <h2>Welcome Back</h2>
            <p>Enter your credentials to access your account</p>
        </div>

        <?php if ($error): ?>
            <div class="error-message" style="display: block;"><?php echo $error; ?></div>
        <?php endif; ?>

        <form action="" method="POST" class="auth-form">
            <div class="form-group">
                <label for="username">Username or Email</label>
                <div class="input-group">
                    <i class="fas fa-user"></i>
                    <input type="text" id="username" name="username" placeholder="Enter your username" required>
                </div>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <div class="input-group">
                    <i class="fas fa-lock"></i>
                    <input type="password" id="password" name="password" placeholder="Enter your password" required>
                </div>
            </div>

            <div class="form-options">
                <label class="remember-me">
                    <input type="checkbox" name="remember"> Remember me
                </label>
                <a href="<?php echo SITE_URL; ?>/forgot-password" style="color: var(--primary-color);">Forgot Password?</a>
            </div>

            <button type="submit" class="btn btn-primary btn-submit">Login to MixoWin</button>
        </form>

        <div class="auth-footer">
            <p>Don't have an account? <a href="<?php echo SITE_URL; ?>/signup">Sign Up</a></p>
        </div>
    </div>
</section>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
