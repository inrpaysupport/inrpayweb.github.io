<?php
$page_title = 'Premium Gaming Experience';
$current_page = 'home';
$extra_css = ['home.css'];

require_once INCLUDES_PATH . '/header.php';
?>

<section class="hero-section">
    <div class="container hero-grid">
        <div class="hero-content">
            <h1 class="animate-fade-in">Experience the <span>Luxury</span> of Gaming</h1>
            <p class="animate-fade-in" style="animation-delay: 0.2s;">Join MixoWin today and discover a world of premium games, exclusive rewards, and a community of elite players.</p>
            <div class="hero-btns animate-fade-in" style="animation-delay: 0.4s; display: flex; gap: 15px;">
                <a href="<?php echo SITE_URL; ?>/signup" class="btn btn-primary">Get Started Now <i class="fas fa-arrow-right"></i></a>
                <a href="<?php echo SITE_URL; ?>/games" class="btn btn-outline">Explore Games</a>
            </div>
        </div>
        <div class="hero-image animate-fade-in" style="animation-delay: 0.3s;">
            <!-- SVG Placeholder for Hero Image -->
            <svg width="500" height="500" viewBox="0 0 500 500" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="250" cy="250" r="200" fill="url(#paint0_linear)" fill-opacity="0.2"/>
                <rect x="150" y="150" width="200" height="200" rx="40" fill="url(#paint1_linear)" />
                <path d="M220 200L300 250L220 300V200Z" fill="white"/>
                <defs>
                    <linearGradient id="paint0_linear" x1="50" y1="50" x2="450" y2="450" gradientUnits="userSpaceOnUse">
                        <stop stop-color="#8E44AD"/>
                        <stop offset="1" stop-color="#F1C40F"/>
                    </linearGradient>
                    <linearGradient id="paint1_linear" x1="150" y1="150" x2="350" y2="350" gradientUnits="userSpaceOnUse">
                        <stop stop-color="#8E44AD"/>
                        <stop offset="1" stop-color="#2980B9"/>
                    </linearGradient>
                </defs>
            </svg>
        </div>
    </div>
</section>

<section class="stats-section">
    <div class="container">
        <div class="stats-grid">
            <div class="stat-card glass-card">
                <span class="stat-value">50k+</span>
                <span class="stat-label">Active Players</span>
            </div>
            <div class="stat-card glass-card">
                <span class="stat-value">$2.5M</span>
                <span class="stat-label">Total Payouts</span>
            </div>
            <div class="stat-card glass-card">
                <span class="stat-value">100+</span>
                <span class="stat-label">Premium Games</span>
            </div>
            <div class="stat-card glass-card">
                <span class="stat-value">24/7</span>
                <span class="stat-label">Expert Support</span>
            </div>
        </div>
    </div>
</section>

<section class="featured-games">
    <div class="container">
        <div class="section-header">
            <h2 class="section-title">Featured Games</h2>
            <a href="<?php echo SITE_URL; ?>/games" class="nav-link">View All <i class="fas fa-chevron-right"></i></a>
        </div>
        
        <div class="game-grid">
            <!-- Game Card: Crash -->
            <a href="<?php echo SITE_URL; ?>/crash" class="game-card glass-card">
                <div style="width: 100%; height: 200px; background: linear-gradient(45deg, #2c3e50, #000); display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-rocket" style="font-size: 60px; color: var(--primary-color);"></i>
                </div>
                <div class="game-overlay">
                    <span class="game-category">Originals</span>
                    <h3 class="game-name">Mixo Crash</h3>
                    <div class="game-meta">
                        <span><i class="fas fa-users"></i> 1,240 Playing</span>
                        <span style="color: var(--accent-color);">99% RTP</span>
                    </div>
                </div>
            </a>
            
            <!-- Game Card: Mines -->
            <a href="<?php echo SITE_URL; ?>/mines" class="game-card glass-card">
                <div style="width: 100%; height: 200px; background: linear-gradient(45deg, #1a1a1a, #333); display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-bomb" style="font-size: 60px; color: #e74c3c;"></i>
                </div>
                <div class="game-overlay">
                    <span class="game-category">Originals</span>
                    <h3 class="game-name">Gold Mines</h3>
                    <div class="game-meta">
                        <span><i class="fas fa-users"></i> 850 Playing</span>
                        <span style="color: var(--accent-color);">98.5% RTP</span>
                    </div>
                </div>
            </a>
            
            <!-- Game Card: Dice -->
            <a href="<?php echo SITE_URL; ?>/dice" class="game-card glass-card">
                <div style="width: 100%; height: 200px; background: linear-gradient(45deg, #2c3e50, #34495e); display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-dice" style="font-size: 60px; color: var(--secondary-color);"></i>
                </div>
                <div class="game-overlay">
                    <span class="game-category">Originals</span>
                    <h3 class="game-name">Royal Dice</h3>
                    <div class="game-meta">
                        <span><i class="fas fa-users"></i> 620 Playing</span>
                        <span style="color: var(--accent-color);">99% RTP</span>
                    </div>
                </div>
            </a>
        </div>
    </div>
</section>

<section class="cta-section" style="margin-top: 100px; margin-bottom: 50px;">
    <div class="container">
        <div class="glass-card" style="padding: 60px; text-align: center; background: linear-gradient(135deg, rgba(142, 68, 173, 0.2), rgba(241, 196, 15, 0.1)); border: 1px solid var(--primary-color);">
            <h2 style="font-size: 36px; margin-bottom: 20px;">Ready to Win Big?</h2>
            <p style="color: var(--text-muted); margin-bottom: 30px; max-width: 600px; margin-left: auto; margin-right: auto;">Join the most exclusive gaming platform and start your journey to the top. Claim your welcome bonus today!</p>
            <a href="<?php echo SITE_URL; ?>/signup" class="btn btn-primary btn-lg" style="padding: 15px 40px; font-size: 18px;">Create Free Account</a>
        </div>
    </div>
</section>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
