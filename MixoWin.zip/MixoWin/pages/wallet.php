<?php
$page_title = 'My Wallet';
$current_page = 'wallet';
$extra_css = ['wallet.css'];

require_once INCLUDES_PATH . '/header.php';

// Require login
Auth::requireLogin();

$user = Auth::user();
$db = getDB();

// Fetch recent transactions
$stmt = $db->prepare("SELECT * FROM demo_transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 10");
$stmt->execute([$user['id']]);
$transactions = $stmt->fetchAll();
?>

<section class="wallet-section" style="padding: 40px 0;">
    <div class="container">
        <div class="wallet-grid">
            <div class="balance-card animate-fade-in">
                <span class="balance-label">Total Available Balance</span>
                <span class="balance-amount">$<?php echo number_format($user['wallet_balance_demo'], 2); ?></span>
                <div class="wallet-actions">
                    <a href="<?php echo SITE_URL; ?>/deposit" class="btn btn-secondary">Deposit <i class="fas fa-plus"></i></a>
                    <a href="<?php echo SITE_URL; ?>/withdraw" class="btn btn-outline" style="color: white; border-color: white;">Withdraw <i class="fas fa-arrow-up"></i></a>
                </div>
            </div>
            
            <div class="rewards-card glass-card animate-fade-in" style="display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center;">
                <div class="action-icon" style="background: rgba(241, 196, 15, 0.1); color: var(--secondary-color);">
                    <i class="fas fa-crown"></i>
                </div>
                <h3 style="font-size: 24px; margin-bottom: 10px;">VIP Rewards</h3>
                <p style="color: var(--text-muted); margin-bottom: 20px;">You have <strong><?php echo number_format($user['reward_points']); ?></strong> points available to redeem.</p>
                <a href="<?php echo SITE_URL; ?>/rewards" class="btn btn-primary btn-sm">Redeem Points</a>
            </div>
        </div>

        <div class="section-header">
            <h2 class="section-title">Quick Actions</h2>
        </div>
        
        <div class="actions-grid" style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 50px;">
            <a href="<?php echo SITE_URL; ?>/deposit" class="action-card glass-card animate-fade-in" style="animation-delay: 0.1s;">
                <div class="action-icon"><i class="fas fa-money-bill-wave"></i></div>
                <h4>Deposit</h4>
            </a>
            <a href="<?php echo SITE_URL; ?>/withdraw" class="action-card glass-card animate-fade-in" style="animation-delay: 0.2s;">
                <div class="action-icon"><i class="fas fa-university"></i></div>
                <h4>Withdraw</h4>
            </a>
            <a href="<?php echo SITE_URL; ?>/history" class="action-card glass-card animate-fade-in" style="animation-delay: 0.3s;">
                <div class="action-icon"><i class="fas fa-list-ul"></i></div>
                <h4>History</h4>
            </a>
            <a href="<?php echo SITE_URL; ?>/referral" class="action-card glass-card animate-fade-in" style="animation-delay: 0.4s;">
                <div class="action-icon"><i class="fas fa-gift"></i></div>
                <h4>Bonus</h4>
            </a>
        </div>

        <div class="section-header">
            <h2 class="section-title">Recent Transactions</h2>
            <a href="<?php echo SITE_URL; ?>/history" class="nav-link">View All</a>
        </div>

        <div class="glass-card animate-fade-in" style="padding: 0; overflow: hidden;">
            <table class="transaction-table">
                <thead>
                    <tr>
                        <th>Type</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($transactions)): ?>
                        <tr>
                            <td colspan="4" style="text-align: center; padding: 40px; color: var(--text-muted);">
                                No transactions found.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($transactions as $tx): ?>
                            <tr>
                                <td style="text-transform: capitalize;"><?php echo $tx['type']; ?></td>
                                <td style="font-weight: 700; color: <?php echo ($tx['type'] == 'deposit' || $tx['type'] == 'reward') ? 'var(--accent-color)' : '#e74c3c'; ?>">
                                    <?php echo ($tx['type'] == 'deposit' || $tx['type'] == 'reward') ? '+' : '-'; ?>
                                    $<?php echo number_format($tx['amount'], 2); ?>
                                </td>
                                <td><span class="status-badge status-<?php echo $tx['status']; ?>"><?php echo ucfirst($tx['status']); ?></span></td>
                                <td><?php echo date('M d, Y H:i', strtotime($tx['created_at'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
