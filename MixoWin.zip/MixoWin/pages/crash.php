<?php
$page_title = 'Mixo Crash';
$current_page = 'games';
$extra_css = ['crash.css'];
$extra_js = ['crash.js'];

require_once INCLUDES_PATH . '/header.php';

// Require login
Auth::requireLogin();
$user = Auth::user();
?>

<section class="game-page" style="padding: 20px 0;">
    <div class="container">
        <div class="history-strip glass-card">
            <span class="history-item history-high">2.45x</span>
            <span class="history-item history-low">1.12x</span>
            <span class="history-item history-high">5.80x</span>
            <span class="history-item history-low">1.05x</span>
            <span class="history-item history-high">12.30x</span>
            <span class="history-item history-high">2.10x</span>
            <span class="history-item history-low">1.50x</span>
            <span class="history-item history-high">3.20x</span>
            <span class="history-item history-low">1.00x</span>
            <span class="history-item history-high">4.15x</span>
        </div>

        <div class="game-container">
            <div class="game-main">
                <div class="crash-display glass-card">
                    <div id="crash-multiplier" class="crash-multiplier">1.00x</div>
                    <div id="crash-rocket" class="crash-rocket">
                        <i class="fas fa-rocket"></i>
                    </div>
                    
                    <!-- SVG Background Stars -->
                    <svg style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; z-index: 1;">
                        <circle cx="10%" cy="20%" r="1" fill="white" opacity="0.5" />
                        <circle cx="30%" cy="60%" r="2" fill="white" opacity="0.3" />
                        <circle cx="70%" cy="30%" r="1" fill="white" opacity="0.6" />
                        <circle cx="90%" cy="80%" r="1.5" fill="white" opacity="0.4" />
                        <circle cx="50%" cy="50%" r="1" fill="white" opacity="0.2" />
                    </svg>
                </div>

                <div class="live-players glass-card" style="padding: 20px;">
                    <h4 style="margin-bottom: 15px;"><i class="fas fa-users" style="color: var(--primary-color);"></i> Live Players</h4>
                    <div style="display: flex; flex-direction: column; gap: 10px;">
                        <div style="display: flex; justify-content: space-between; font-size: 14px; color: var(--text-muted); border-bottom: 1px solid rgba(255,255,255,0.05); padding-bottom: 5px;">
                            <span>User</span>
                            <span>Bet</span>
                            <span>Multiplier</span>
                            <span>Profit</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; font-size: 14px;">
                            <span>Player_99</span>
                            <span>$10.00</span>
                            <span style="color: var(--accent-color);">2.10x</span>
                            <span style="color: var(--accent-color);">+$11.00</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; font-size: 14px;">
                            <span>HighRoller</span>
                            <span>$500.00</span>
                            <span style="color: var(--text-muted);">-</span>
                            <span style="color: var(--text-muted);">-</span>
                        </div>
                        <div style="display: flex; justify-content: space-between; font-size: 14px;">
                            <span>MixoKing</span>
                            <span>$50.00</span>
                            <span style="color: var(--accent-color);">1.50x</span>
                            <span style="color: var(--accent-color);">+$25.00</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="game-sidebar">
                <div class="bet-controls glass-card">
                    <div class="form-group" style="margin-bottom: 20px;">
                        <label style="color: var(--text-muted); font-size: 14px; margin-bottom: 10px; display: block;">Bet Amount</label>
                        <div class="bet-input-group">
                            <div class="bet-input-wrapper">
                                <i class="fas fa-dollar-sign"></i>
                                <input type="number" id="bet-amount" value="10.00" step="1.00" min="0.1">
                            </div>
                        </div>
                        <div class="bet-multiplier-btns">
                            <button onclick="document.getElementById('bet-amount').value = (parseFloat(document.getElementById('bet-amount').value) / 2).toFixed(2)">1/2</button>
                            <button onclick="document.getElementById('bet-amount').value = (parseFloat(document.getElementById('bet-amount').value) * 2).toFixed(2)">2x</button>
                            <button onclick="document.getElementById('bet-amount').value = '10.00'">Min</button>
                            <button onclick="document.getElementById('bet-amount').value = '1000.00'">Max</button>
                        </div>
                    </div>

                    <div class="form-group" style="margin-bottom: 25px;">
                        <label style="color: var(--text-muted); font-size: 14px; margin-bottom: 10px; display: block;">Auto Cash Out</label>
                        <div class="bet-input-wrapper">
                            <i class="fas fa-times"></i>
                            <input type="number" id="auto-cashout" value="2.00" step="0.1" min="1.01">
                        </div>
                    </div>

                    <button id="btn-bet" class="btn btn-primary btn-bet">Place Bet</button>
                    
                    <div style="margin-top: 20px; display: flex; justify-content: space-between; font-size: 14px; color: var(--text-muted);">
                        <span>Wallet Balance:</span>
                        <span style="color: white; font-weight: 700;">$<?php echo number_format($user['wallet_balance_demo'], 2); ?></span>
                    </div>
                </div>

                <div class="game-info glass-card" style="margin-top: 20px; padding: 20px;">
                    <h4 style="margin-bottom: 10px;">How to Play</h4>
                    <p style="font-size: 13px; color: var(--text-muted); line-height: 1.4;">
                        Place your bet and watch the multiplier grow from 1.00x upwards. Cash out at any time to multiply your bet by that amount. But be careful, the game can crash at any moment!
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
