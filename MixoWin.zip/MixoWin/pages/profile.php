<?php
$page_title = 'My Profile';
$current_page = 'profile';
$extra_css = ['profile.css'];

require_once INCLUDES_PATH . '/header.php';

// Require login
Auth::requireLogin();

$user = Auth::user();
?>

<section class="profile-section" style="padding: 40px 0;">
    <div class="container">
        <div class="profile-grid" style="display: grid; grid-template-columns: 300px 1fr; gap: 30px;">
            <!-- Sidebar -->
            <div class="profile-sidebar">
                <div class="glass-card" style="text-align: center; padding: 30px;">
                    <div class="profile-avatar" style="position: relative; display: inline-block; margin-bottom: 20px;">
                        <img src="<?php echo SITE_URL; ?>/assets/avatars/<?php echo $user['avatar']; ?>" alt="Avatar" style="width: 120px; height: 120px; border-radius: 50%; border: 4px solid var(--primary-color);">
                        <span style="position: absolute; bottom: 5px; right: 5px; width: 20px; height: 20px; background: var(--accent-color); border-radius: 50%; border: 3px solid var(--bg-color);"></span>
                    </div>
                    <h3 style="font-size: 22px; margin-bottom: 5px;"><?php echo $user['full_name']; ?></h3>
                    <p style="color: var(--text-muted); margin-bottom: 20px;">@<?php echo $user['username']; ?></p>
                    
                    <div class="vip-badge" style="background: linear-gradient(135deg, var(--secondary-color), #d4ac0d); color: #000; padding: 5px 15px; border-radius: 20px; font-weight: 700; font-size: 12px; display: inline-block; margin-bottom: 20px;">
                        VIP LEVEL <?php echo $user['vip_level']; ?>
                    </div>
                    
                    <div class="profile-nav" style="text-align: left; margin-top: 20px;">
                        <a href="<?php echo SITE_URL; ?>/profile" class="nav-link active" style="display: block; padding: 12px 15px; border-radius: 10px; background: rgba(142, 68, 173, 0.1); color: var(--primary-color); margin-bottom: 5px;"><i class="fas fa-user" style="margin-right: 10px;"></i> Dashboard</a>
                        <a href="<?php echo SITE_URL; ?>/wallet" class="nav-link" style="display: block; padding: 12px 15px; margin-bottom: 5px;"><i class="fas fa-wallet" style="margin-right: 10px;"></i> My Wallet</a>
                        <a href="<?php echo SITE_URL; ?>/history" class="nav-link" style="display: block; padding: 12px 15px; margin-bottom: 5px;"><i class="fas fa-history" style="margin-right: 10px;"></i> Game History</a>
                        <a href="<?php echo SITE_URL; ?>/referral" class="nav-link" style="display: block; padding: 12px 15px; margin-bottom: 5px;"><i class="fas fa-users" style="margin-right: 10px;"></i> Referrals</a>
                        <a href="<?php echo SITE_URL; ?>/settings" class="nav-link" style="display: block; padding: 12px 15px; margin-bottom: 5px;"><i class="fas fa-cog" style="margin-right: 10px;"></i> Settings</a>
                        <a href="<?php echo SITE_URL; ?>/logout" class="nav-link" style="display: block; padding: 12px 15px; color: #e74c3c;"><i class="fas fa-sign-out-alt" style="margin-right: 10px;"></i> Logout</a>
                    </div>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="profile-main">
                <div class="stats-overview" style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 30px;">
                    <div class="glass-card" style="padding: 20px; border-left: 4px solid var(--primary-color);">
                        <span style="color: var(--text-muted); font-size: 14px;">Total Balance</span>
                        <h4 style="font-size: 24px; color: var(--text-color);">$<?php echo number_format($user['wallet_balance_demo'], 2); ?></h4>
                    </div>
                    <div class="glass-card" style="padding: 20px; border-left: 4px solid var(--secondary-color);">
                        <span style="color: var(--text-muted); font-size: 14px;">Reward Points</span>
                        <h4 style="font-size: 24px; color: var(--text-color);"><?php echo number_format($user['reward_points']); ?></h4>
                    </div>
                    <div class="glass-card" style="padding: 20px; border-left: 4px solid var(--accent-color);">
                        <span style="color: var(--text-muted); font-size: 14px;">Total Wins</span>
                        <h4 style="font-size: 24px; color: var(--text-color);">0</h4>
                    </div>
                </div>
                
                <div class="glass-card" style="padding: 30px; margin-bottom: 30px;">
                    <h3 style="margin-bottom: 20px;">Recent Activity</h3>
                    <div style="text-align: center; padding: 40px; color: var(--text-muted);">
                        <i class="fas fa-info-circle" style="font-size: 40px; margin-bottom: 15px; display: block;"></i>
                        <p>No recent activity found. Start playing to see your history!</p>
                        <a href="<?php echo SITE_URL; ?>/games" class="btn btn-primary" style="margin-top: 20px;">Explore Games</a>
                    </div>
                </div>
                
                <div class="glass-card" style="padding: 30px;">
                    <h3 style="margin-bottom: 20px;">Referral Program</h3>
                    <div style="display: flex; justify-content: space-between; align-items: center; background: rgba(255,255,255,0.03); padding: 20px; border-radius: 15px;">
                        <div>
                            <p style="color: var(--text-muted); font-size: 14px;">Your Referral Code</p>
                            <h4 style="font-size: 20px; letter-spacing: 2px; color: var(--secondary-color);"><?php echo $user['referral_code']; ?></h4>
                        </div>
                        <button class="btn btn-outline btn-sm" onclick="navigator.clipboard.writeText('<?php echo $user['referral_code']; ?>')">Copy Code</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
