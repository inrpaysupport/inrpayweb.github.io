<?php
$page_title = 'Create Account';
$current_page = 'signup';
$extra_css = ['login.css'];

require_once INCLUDES_PATH . '/header.php';

// Check if already logged in
if (Auth::isLoggedIn()) {
    header("Location: " . SITE_URL . "/profile");
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = $_POST['full_name'] ?? '';
    $username = $_POST['username'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    if (empty($full_name) || empty($username) || empty($email) || empty($password)) {
        $error = 'All fields are required.';
    } elseif ($password !== $confirm_password) {
        $error = 'Passwords do not match.';
    } else {
        $db = getDB();
        
        // Check if username or email exists
        $stmt = $db->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $email]);
        if ($stmt->fetch()) {
            $error = 'Username or email already exists.';
        } else {
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            $referral_code = Auth::generateReferralCode();
            
            try {
                $stmt = $db->prepare("INSERT INTO users (full_name, username, email, password_hash, referral_code, wallet_balance_demo) VALUES (?, ?, ?, ?, ?, 100.00)");
                $stmt->execute([$full_name, $username, $email, $password_hash, $referral_code]);
                
                $user_id = $db->lastInsertId();
                
                // Create profile
                $stmt = $db->prepare("INSERT INTO profiles (user_id) VALUES (?)");
                $stmt->execute([$user_id]);
                
                $success = 'Account created successfully! You can now login.';
            } catch (Exception $e) {
                $error = 'An error occurred. Please try again.';
            }
        }
    }
}
?>

<section class="auth-section">
    <div class="auth-container glass-card animate-fade-in" style="max-width: 500px;">
        <div class="auth-header">
            <h2>Join MixoWin</h2>
            <p>Start your luxury gaming journey today</p>
        </div>

        <?php if ($error): ?>
            <div class="error-message" style="display: block;"><?php echo $error; ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="success-message" style="background: rgba(46, 204, 113, 0.1); border: 1px solid #2ecc71; color: #2ecc71; padding: 12px; border-radius: 10px; margin-bottom: 20px; text-align: center;">
                <?php echo $success; ?>
                <div style="margin-top: 10px;"><a href="<?php echo SITE_URL; ?>/login" class="btn btn-primary btn-sm">Login Now</a></div>
            </div>
        <?php endif; ?>

        <form action="" method="POST" class="auth-form">
            <div class="form-group">
                <label for="full_name">Full Name</label>
                <div class="input-group">
                    <i class="fas fa-id-card"></i>
                    <input type="text" id="full_name" name="full_name" placeholder="Enter your full name" required>
                </div>
            </div>

            <div class="form-group">
                <label for="username">Username</label>
                <div class="input-group">
                    <i class="fas fa-user"></i>
                    <input type="text" id="username" name="username" placeholder="Choose a username" required>
                </div>
            </div>

            <div class="form-group">
                <label for="email">Email Address</label>
                <div class="input-group">
                    <i class="fas fa-envelope"></i>
                    <input type="email" id="email" name="email" placeholder="Enter your email" required>
                </div>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <div class="input-group">
                    <i class="fas fa-lock"></i>
                    <input type="password" id="password" name="password" placeholder="Create a password" required>
                </div>
            </div>

            <div class="form-group">
                <label for="confirm_password">Confirm Password</label>
                <div class="input-group">
                    <i class="fas fa-check-circle"></i>
                    <input type="password" id="confirm_password" name="confirm_password" placeholder="Repeat your password" required>
                </div>
            </div>

            <div class="form-options">
                <label class="remember-me" style="font-size: 13px;">
                    <input type="checkbox" name="terms" required> I agree to the <a href="#" style="color: var(--primary-color);">Terms & Conditions</a>
                </label>
            </div>

            <button type="submit" class="btn btn-primary btn-submit">Create My Account</button>
        </form>

        <div class="auth-footer">
            <p>Already have an account? <a href="<?php echo SITE_URL; ?>/login">Login</a></p>
        </div>
    </div>
</section>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
