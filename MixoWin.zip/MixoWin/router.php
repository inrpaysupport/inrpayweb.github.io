<?php
/**
 * MixoWin - Simple Router
 * Version: 1.0
 */

require_once 'config.php';

function route($path) {
    $path = trim($path, '/');
    
    // Basic routing logic
    if (empty($path)) {
        require_once PAGES_PATH . '/home.php';
        return;
    }

    $file = PAGES_PATH . '/' . $path . '.php';
    if (file_exists($file)) {
        require_once $file;
    } else {
        // Handle 404
        http_response_code(404);
        require_once PAGES_PATH . '/404.php';
    }
}
?>
