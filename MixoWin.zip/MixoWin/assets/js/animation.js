/**
 * MixoWin - Animation JavaScript
 * Version: 1.0
 */

document.addEventListener('DOMContentLoaded', () => {
    // Intersection Observer for fade-in animations
    const observerOptions = {
        threshold: 0.1
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-fade-in');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    // Apply observer to elements with animation classes
    document.querySelectorAll('.glass-card, .btn, .game-card').forEach(el => {
        el.style.opacity = '0';
        observer.observe(el);
    });
});
