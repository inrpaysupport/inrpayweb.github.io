/**
 * MixoWin - Global JavaScript
 * Version: 1.0
 */

document.addEventListener('DOMContentLoaded', () => {
    console.log('MixoWin initialized');
    
    // Global utility functions
    window.MixoWin = {
        formatCurrency: (amount) => {
            return new Intl.NumberFormat('en-US', {
                style: 'currency',
                currency: 'USD',
            }).format(amount);
        },
        
        showToast: (message, type = 'success') => {
            // Toast implementation will be added later
            alert(message);
        }
    };
});
