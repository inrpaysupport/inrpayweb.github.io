/**
 * MixoWin - Crash Game Logic (Demo)
 * Version: 1.0
 */

class CrashGame {
    constructor() {
        this.multiplier = 1.00;
        this.isGameRunning = false;
        this.isCrashed = false;
        this.betAmount = 0;
        this.hasBet = false;
        
        this.displayEl = document.getElementById('crash-multiplier');
        this.rocketEl = document.getElementById('crash-rocket');
        this.betBtn = document.getElementById('btn-bet');
        this.betInput = document.getElementById('bet-amount');
        
        this.init();
    }

    init() {
        if (!this.betBtn) return;
        
        this.betBtn.addEventListener('click', () => {
            if (!this.isGameRunning) {
                this.placeBet();
            } else if (this.hasBet && !this.isCrashed) {
                this.cashOut();
            }
        });
        
        // Start game loop automatically for demo
        this.startNewRound();
    }

    startNewRound() {
        this.multiplier = 1.00;
        this.isGameRunning = false;
        this.isCrashed = false;
        this.hasBet = false;
        
        this.displayEl.style.color = 'white';
        this.displayEl.innerText = '1.00x';
        this.betBtn.innerText = 'Place Bet';
        this.betBtn.classList.remove('btn-secondary');
        this.betBtn.classList.add('btn-primary');
        
        let countdown = 5;
        const timer = setInterval(() => {
            this.displayEl.innerText = `Starting in ${countdown}s`;
            countdown--;
            
            if (countdown < 0) {
                clearInterval(timer);
                this.runGame();
            }
        }, 1000);
    }

    runGame() {
        this.isGameRunning = true;
        this.displayEl.style.color = 'var(--secondary-color)';
        
        if (this.hasBet) {
            this.betBtn.innerText = 'Cash Out';
            this.betBtn.classList.remove('btn-primary');
            this.betBtn.classList.add('btn-secondary');
        }

        const crashPoint = (Math.random() * 5 + 1).toFixed(2);
        
        const gameLoop = setInterval(() => {
            this.multiplier += 0.01;
            this.displayEl.innerText = this.multiplier.toFixed(2) + 'x';
            
            // Move rocket
            const pos = (this.multiplier - 1) * 50;
            this.rocketEl.style.bottom = (50 + pos) + 'px';
            this.rocketEl.style.left = (50 + pos) + 'px';

            if (this.multiplier >= crashPoint) {
                clearInterval(gameLoop);
                this.crash();
            }
        }, 50);
    }

    crash() {
        this.isCrashed = true;
        this.displayEl.style.color = '#e74c3c';
        this.displayEl.innerText = 'CRASHED @ ' + this.multiplier.toFixed(2) + 'x';
        this.betBtn.innerText = 'Crashed!';
        this.betBtn.disabled = true;
        
        setTimeout(() => {
            this.betBtn.disabled = false;
            this.startNewRound();
        }, 3000);
    }

    placeBet() {
        const amount = parseFloat(this.betInput.value);
        if (isNaN(amount) || amount <= 0) return;
        
        this.betAmount = amount;
        this.hasBet = true;
        this.betBtn.innerText = 'Bet Placed';
        this.betBtn.disabled = true;
    }

    cashOut() {
        const winAmount = this.betAmount * this.multiplier;
        this.hasBet = false;
        this.betBtn.innerText = 'Won $' + winAmount.toFixed(2);
        this.betBtn.disabled = true;
        this.displayEl.style.color = 'var(--accent-color)';
        
        // In a real app, you'd send this to the API
        console.log('Cashed out at', this.multiplier, 'Win:', winAmount);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new CrashGame();
});
