# MixoWin - Premium Gaming Platform

MixoWin is a production-quality web application designed with a "Dark Luxury" theme. It features a complete gaming ecosystem with user authentication, wallet management, and original games.

## Features

- **Luxury Design**: Dark theme with Purple and Gold accents, featuring Glassmorphism and smooth animations.
- **Authentication**: Secure login, signup, and profile management.
- **Wallet System**: Demo wallet for deposits, withdrawals, and transaction history.
- **Games**: Original games like "Mixo Crash" with real-time multiplier logic.
- **Admin Panel**: Dedicated portal for managing users, transactions, and site settings.
- **PWA Ready**: Mobile-first responsive design suitable for installation as a Progressive Web App.

## Technology Stack

- **Frontend**: HTML5, CSS3 (Custom), Vanilla JavaScript ES6.
- **Backend**: PHP 8.2.
- **Database**: MySQL (PDO with Prepared Statements).
- **Icons**: Font Awesome 6.
- **Fonts**: Google Fonts (Poppins).

## Installation

1. **Clone the project** to your web server directory (e.g., `/var/www/html/MixoWin`).
2. **Import the database**:
   - Create a database named `mixowin_db`.
   - Import the `database/schema.sql` file.
3. **Configure the application**:
   - Edit `config.php` to match your database credentials and site URL.
4. **Server Requirements**:
   - Apache with `mod_rewrite` enabled (for `.htaccess` routing).
   - PHP 8.2 or higher.
   - MySQL 5.7 or higher.

## Folder Structure

```
MixoWin/
├── admin/          # Admin portal pages
├── api/            # JSON API endpoints
├── assets/         # CSS, JS, Images, Icons, etc.
├── database/       # SQL schema
├── includes/       # Reusable PHP components and helpers
├── pages/          # Public facing website pages
├── config.php      # Main configuration
├── db.php          # Database connection class
├── index.php       # Entry point
└── router.php      # Simple routing logic
```

## Admin Credentials (Demo)

- **URL**: `/admin/login.php`
- **Username**: `admin`
- **Password**: `password`

## License

This project is for demonstration purposes. All rights reserved.
