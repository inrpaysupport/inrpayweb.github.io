<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/auth.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' | ' . SITE_NAME : SITE_NAME; ?></title>
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/style.css">
    <?php if (isset($extra_css)): ?>
        <?php foreach ($extra_css as $css): ?>
            <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/<?php echo $css; ?>">
        <?php endforeach; ?>
    <?php endif; ?>
</head>
<body>
    <header>
        <div class="container header-content">
            <a href="<?php echo SITE_URL; ?>" class="logo">
                <i class="fas fa-gamepad"></i> MIXO<span>WIN</span>
            </a>
            
            <nav class="nav-links">
                <a href="<?php echo SITE_URL; ?>" class="nav-link <?php echo (!isset($current_page) || $current_page == 'home') ? 'active' : ''; ?>">Home</a>
                <a href="<?php echo SITE_URL; ?>/games" class="nav-link <?php echo (isset($current_page) && $current_page == 'games') ? 'active' : ''; ?>">Games</a>
                <a href="<?php echo SITE_URL; ?>/leaderboard" class="nav-link <?php echo (isset($current_page) && $current_page == 'leaderboard') ? 'active' : ''; ?>">Leaderboard</a>
                <a href="<?php echo SITE_URL; ?>/rewards" class="nav-link <?php echo (isset($current_page) && $current_page == 'rewards') ? 'active' : ''; ?>">Rewards</a>
            </nav>
            
            <div class="user-actions">
                <?php if (Auth::isLoggedIn()): ?>
                    <?php $user = Auth::user(); ?>
                    <div class="wallet-summary glass-card" style="padding: 8px 15px; display: flex; align-items: center; gap: 10px;">
                        <i class="fas fa-wallet" style="color: var(--secondary-color);"></i>
                        <span style="font-weight: 700;">$<?php echo number_format($user['wallet_balance_demo'], 2); ?></span>
                    </div>
                    <a href="<?php echo SITE_URL; ?>/notifications" class="nav-link"><i class="fas fa-bell"></i></a>
                    <a href="<?php echo SITE_URL; ?>/profile" class="user-avatar">
                        <img src="<?php echo SITE_URL; ?>/assets/avatars/<?php echo $user['avatar']; ?>" alt="Avatar" style="width: 40px; height: 40px; border-radius: 50%; border: 2px solid var(--primary-color);">
                    </a>
                <?php else: ?>
                    <a href="<?php echo SITE_URL; ?>/login" class="btn btn-outline">Login</a>
                    <a href="<?php echo SITE_URL; ?>/signup" class="btn btn-primary">Sign Up</a>
                <?php endif; ?>
            </div>
        </div>
    </header>
    <main>
