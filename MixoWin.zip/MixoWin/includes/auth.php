<?php
/**
 * MixoWin - Authentication Helper
 * Version: 1.0
 */

require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/session.php';

class Auth {
    public static function login($username, $password) {
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password_hash'])) {
            if ($user['account_status'] === 'suspended') {
                return ['success' => false, 'message' => 'Your account has been suspended.'];
            }
            
            Session::set('user_id', $user['id']);
            Session::set('username', $user['username']);
            Session::set('vip_level', $user['vip_level']);
            
            return ['success' => true];
        }

        return ['success' => false, 'message' => 'Invalid username or password.'];
    }

    public static function logout() {
        Session::destroy();
    }

    public static function isLoggedIn() {
        return Session::has('user_id');
    }

    public static function user() {
        if (!self::isLoggedIn()) return null;
        
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([Session::get('user_id')]);
        return $stmt->fetch();
    }

    public static function requireLogin() {
        if (!self::isLoggedIn()) {
            header("Location: " . SITE_URL . "/login.php");
            exit();
        }
    }

    public static function generateReferralCode() {
        return strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 8));
    }
}
?>
