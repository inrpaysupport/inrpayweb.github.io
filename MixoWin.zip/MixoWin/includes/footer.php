    </main>
    
    <footer>
        <div class="container">
            <div class="footer-grid">
                <div class="footer-info">
                    <a href="<?php echo SITE_URL; ?>" class="logo" style="margin-bottom: 20px; display: inline-flex;">
                        <i class="fas fa-gamepad"></i> MIXO<span>WIN</span>
                    </a>
                    <p style="color: var(--text-muted); margin-bottom: 20px;">
                        The ultimate destination for premium gaming and luxury entertainment. Play, win, and rise to the top of the leaderboard.
                    </p>
                    <div class="social-links" style="display: flex; gap: 15px;">
                        <a href="#" class="glass-card" style="padding: 10px; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center;"><i class="fab fa-telegram"></i></a>
                        <a href="#" class="glass-card" style="padding: 10px; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center;"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="glass-card" style="padding: 10px; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center;"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="glass-card" style="padding: 10px; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center;"><i class="fab fa-discord"></i></a>
                    </div>
                </div>
                
                <div class="footer-section">
                    <h4 class="footer-title">Quick Links</h4>
                    <ul class="footer-links">
                        <li><a href="<?php echo SITE_URL; ?>">Home</a></li>
                        <li><a href="<?php echo SITE_URL; ?>/games">All Games</a></li>
                        <li><a href="<?php echo SITE_URL; ?>/leaderboard">Leaderboard</a></li>
                        <li><a href="<?php echo SITE_URL; ?>/rewards">Rewards</a></li>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h4 class="footer-title">Support</h4>
                    <ul class="footer-links">
                        <li><a href="<?php echo SITE_URL; ?>/support">Help Center</a></li>
                        <li><a href="<?php echo SITE_URL; ?>/faq">FAQ</a></li>
                        <li><a href="<?php echo SITE_URL; ?>/terms">Terms of Service</a></li>
                        <li><a href="<?php echo SITE_URL; ?>/privacy">Privacy Policy</a></li>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h4 class="footer-title">Newsletter</h4>
                    <p style="color: var(--text-muted); margin-bottom: 15px; font-size: 14px;">Subscribe to get the latest updates and bonuses.</p>
                    <form style="display: flex; gap: 10px;">
                        <input type="email" placeholder="Your email" class="glass-card" style="flex: 1; padding: 10px; border: none; outline: none; color: white;">
                        <button type="submit" class="btn btn-primary" style="padding: 10px 15px;"><i class="fas fa-paper-plane"></i></button>
                    </form>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. All rights reserved. Play responsibly.</p>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="<?php echo SITE_URL; ?>/assets/js/app.js"></script>
    <script src="<?php echo SITE_URL; ?>/assets/js/animation.js"></script>
    <?php if (isset($extra_js)): ?>
        <?php foreach ($extra_js as $js): ?>
            <script src="<?php echo SITE_URL; ?>/assets/js/<?php echo $js; ?>"></script>
        <?php endforeach; ?>
    <?php endif; ?>
</body>
</html>
