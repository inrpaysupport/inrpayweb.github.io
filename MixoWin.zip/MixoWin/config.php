<?php
/**
 * MixoWin - Configuration File
 * Version: 1.0
 */

// Error reporting for development
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Site Configuration
define('SITE_NAME', 'MixoWin');
define('SITE_URL', 'http://localhost/MixoWin'); // Update this when deploying
define('SITE_VERSION', '1.0.0');

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'mixowin_db');
define('DB_USER', 'root');
define('DB_PASS', '');

// Session Configuration
define('SESSION_LIFETIME', 3600); // 1 hour

// Security
define('CSRF_TOKEN_SECRET', 'mixowin_secret_key_12345'); // Change this in production

// Paths
define('BASE_PATH', __DIR__);
define('INCLUDES_PATH', BASE_PATH . '/includes');
define('PAGES_PATH', BASE_PATH . '/pages');
define('ASSETS_PATH', SITE_URL . '/assets');

// Timezone
date_default_timezone_set('UTC');

// Initialize Session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
