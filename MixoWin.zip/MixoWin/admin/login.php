<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../db.php';
require_once INCLUDES_PATH . '/session.php';

$page_title = 'Admin Login';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    // Simple admin check for demo (username: admin, password: password)
    if ($username === 'admin' && $password === 'password') {
        Session::set('admin_id', 1);
        Session::set('admin_username', 'admin');
        header("Location: dashboard.php");
        exit();
    } else {
        $error = 'Invalid admin credentials.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> | MixoWin</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/style.css">
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/login.css">
</head>
<body style="background: #05070a;">
    <section class="auth-section">
        <div class="auth-container glass-card">
            <div class="auth-header">
                <div class="logo" style="justify-content: center; margin-bottom: 20px;">
                    <i class="fas fa-user-shield"></i> MIXO<span>ADMIN</span>
                </div>
                <h2>Admin Portal</h2>
                <p>Secure access for administrators only</p>
            </div>

            <?php if ($error): ?>
                <div class="error-message" style="display: block;"><?php echo $error; ?></div>
            <?php endif; ?>

            <form action="" method="POST" class="auth-form">
                <div class="form-group">
                    <label>Admin Username</label>
                    <div class="input-group">
                        <i class="fas fa-user-shield"></i>
                        <input type="text" name="username" placeholder="Admin username" required>
                    </div>
                </div>

                <div class="form-group">
                    <label>Password</label>
                    <div class="input-group">
                        <i class="fas fa-key"></i>
                        <input type="password" name="password" placeholder="Admin password" required>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary btn-submit">Enter Dashboard</button>
            </form>
            
            <div style="text-align: center; margin-top: 20px;">
                <a href="<?php echo SITE_URL; ?>" style="color: var(--text-muted); font-size: 14px;"><i class="fas fa-arrow-left"></i> Back to Site</a>
            </div>
        </div>
    </section>
</body>
</html>
