<?php
/**
 * MixoWin - Entry Point
 * Version: 1.0
 */

require_once 'config.php';
require_once 'db.php';
require_once 'router.php';
require_once INCLUDES_PATH . '/auth.php';

// Get the current path from the URL
$request_uri = $_SERVER['REQUEST_URI'];
$base_url_path = parse_url(SITE_URL, PHP_URL_PATH);
$path = str_replace($base_url_path, '', $request_uri);
$path = parse_url($path, PHP_URL_PATH);

// Start routing
route($path);
?>
