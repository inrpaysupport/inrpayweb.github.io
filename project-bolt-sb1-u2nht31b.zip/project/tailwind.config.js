/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        // Midnight background ramp
        midnight: {
          950: '#050610',
          900: '#070913',
          850: '#0a0c1a',
          800: '#0d1020',
        },
        // Dark-slate panel surfaces
        slatepanel: {
          950: '#0b0e1f',
          900: '#0f1225',
          800: '#141833',
          700: '#1a1f3f',
          600: '#232853',
        },
        // Structural borders
        borderline: {
          900: '#1f244a',
          800: '#2a3066',
          700: '#3a4180',
        },
        // Neon purple-pink accent
        neon: {
          50: '#f5ebff',
          100: '#e9d3ff',
          200: '#d4a6ff',
          300: '#c07bff',
          400: '#b15eff',
          500: '#9a3eff',
          600: '#7c1fd6',
          700: '#5e14a3',
        },
        // Emerald winnings
        emeraldwin: {
          300: '#5cffb0',
          400: '#1aff99',
          500: '#00ff88',
          600: '#00d973',
          700: '#00a85a',
        },
        // Coral red losses
        coral: {
          300: '#ff7088',
          400: '#ff4d70',
          500: '#ff3366',
          600: '#e01f50',
          700: '#b3143d',
        },
        // Amber warning
        amberx: {
          400: '#ffcc4d',
          500: '#ffb020',
          600: '#e0910a',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        display: ['Sora', 'Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'ui-monospace', 'monospace'],
      },
      boxShadow: {
        'neon-glow': '0 0 24px -2px rgba(177, 94, 255, 0.45)',
        'neon-glow-lg': '0 0 40px -4px rgba(177, 94, 255, 0.55)',
        'emerald-glow': '0 0 24px -2px rgba(0, 255, 136, 0.4)',
        'coral-glow': '0 0 24px -2px rgba(255, 51, 102, 0.4)',
        'fab': '0 10px 30px -6px rgba(177, 94, 255, 0.65), 0 4px 12px -2px rgba(0,0,0,0.5)',
      },
      keyframes: {
        'fade-in': {
          '0%': { opacity: '0', transform: 'translateY(8px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'slide-in': {
          '0%': { opacity: '0', transform: 'translateX(24px)' },
          '100%': { opacity: '1', transform: 'translateX(0)' },
        },
        'pulse-glow': {
          '0%, 100%': { boxShadow: '0 0 0 0 rgba(177, 94, 255, 0.5)' },
          '50%': { boxShadow: '0 0 0 8px rgba(177, 94, 255, 0)' },
        },
        'shimmer': {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
        'gem-pop': {
          '0%': { transform: 'scale(0) rotate(-30deg)', opacity: '0' },
          '60%': { transform: 'scale(1.15) rotate(8deg)', opacity: '1' },
          '100%': { transform: 'scale(1) rotate(0)', opacity: '1' },
        },
        'mine-blast': {
          '0%': { transform: 'scale(0.4)', opacity: '0' },
          '40%': { transform: 'scale(1.3)', opacity: '1' },
          '100%': { transform: 'scale(1)', opacity: '1' },
        },
        'ticker-blink': {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0.55' },
        },
      },
      animation: {
        'fade-in': 'fade-in 0.4s ease-out',
        'slide-in': 'slide-in 0.4s ease-out',
        'pulse-glow': 'pulse-glow 2s ease-in-out infinite',
        'shimmer': 'shimmer 2.5s linear infinite',
        'gem-pop': 'gem-pop 0.35s cubic-bezier(0.34, 1.56, 0.64, 1)',
        'mine-blast': 'mine-blast 0.4s ease-out',
        'ticker-blink': 'ticker-blink 1s ease-in-out infinite',
      },
    },
  },
  plugins: [],
};
