import { useState } from 'react';
import { crashEngine } from '../lib/crashEngine';
import { useCrashBets, useCrashState } from '../lib/hooks';
import { store } from '../lib/store';
import { Check, Lock, X, Zap } from 'lucide-react';
import type { BetSlot } from '../lib/crashEngine';

function BetConsole({ id }: { id: 'A' | 'B' }) {
  const bets = useCrashBets();
  const state = useCrashState();
  const slot: BetSlot = bets[id];
  const [amount, setAmount] = useState('100');
  const [autoTarget, setAutoTarget] = useState('2.00');
  const [autoEnabled, setAutoEnabled] = useState(false);

  const phase = state.phase;
  const canPlace = phase === 'countdown' && !slot.placed;
  const canCancel = phase === 'countdown' && slot.placed;
  const canCashout = phase === 'flying' && slot.placed && !slot.cashedOut;

  const place = () => {
    const amt = parseFloat(amount);
    const res = crashEngine.placeBet(id, amt);
    if (!res.ok) store.pushNotification({ title: `Bet ${id} failed`, body: res.reason || '', kind: 'warn' });
  };

  const cashout = () => {
    const res = crashEngine.cashOut(id);
    if (!res.ok) store.pushNotification({ title: `Bet ${id} cashout failed`, body: res.reason || '', kind: 'warn' });
  };

  const toggleAuto = () => {
    const next = !autoEnabled;
    setAutoEnabled(next);
    crashEngine.setAuto(id, next, parseFloat(autoTarget) || 2);
  };

  const setAutoTargetVal = (v: string) => {
    setAutoTarget(v);
    if (autoEnabled) crashEngine.setAuto(id, true, parseFloat(v) || 2);
  };

  const quickAmt = (v: number) => {
    setAmount(String(v));
  };

  const accent = id === 'A' ? 'neon' : 'emeraldwin';

  return (
    <div className={`panel p-3 sm:p-4 ${slot.cashedOut && slot.win ? 'ring-1 ring-emeraldwin-500/40' : ''} ${slot.cashedOut && slot.win === 0 ? 'ring-1 ring-coral-500/40' : ''}`}>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className={`w-7 h-7 rounded-lg grid place-items-center font-display font-extrabold text-sm ${id === 'A' ? 'bg-neon-500/20 text-neon-300 border border-neon-500/40' : 'bg-emeraldwin-500/20 text-emeraldwin-400 border border-emeraldwin-500/40'}`}>
            {id}
          </span>
          <span className="text-xs font-semibold text-slate-400">Bet Control {id}</span>
        </div>
        {slot.placed && !slot.cashedOut && (
          <span className="chip bg-midnight-850 border border-borderline-900 text-slate-300 text-[10px]">
            <Lock className="w-3 h-3" /> Locked
          </span>
        )}
        {slot.cashedOut && slot.win !== null && slot.win > 0 && (
          <span className="chip bg-emeraldwin-500/15 border border-emeraldwin-500/40 text-emeraldwin-400 text-[10px]">
            Won {store.currency}{slot.win.toFixed(2)}
          </span>
        )}
        {slot.cashedOut && slot.win === 0 && (
          <span className="chip bg-coral-500/15 border border-coral-500/40 text-coral-400 text-[10px]">Busted</span>
        )}
      </div>

      {/* Amount + action */}
      <div className="flex flex-col gap-2 mb-2">
        <div className="relative">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 font-bold text-sm">{store.currency}</span>
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            disabled={slot.placed}
            min={1}
            className="input pl-7 tabular"
            placeholder="100"
          />
        </div>
        {!slot.placed ? (
          <button onClick={place} disabled={!canPlace} className={`btn-primary py-2.5 ${accent === 'emeraldwin' ? 'from-emeraldwin-400 to-emeraldwin-600 text-midnight-900 shadow-emerald-glow' : ''}`}>
            Place Bet
          </button>
        ) : canCashout ? (
          <button onClick={cashout} className="btn-emerald py-2.5 flex-col gap-0 leading-tight">
            <span className="text-xs">Cash Out</span>
            {slot.placed && phase === 'flying' && (
              <span className="tabular text-sm">{store.currency}{(slot.amount * state.multiplier).toFixed(2)}</span>
            )}
          </button>
        ) : (
          <button onClick={() => crashEngine.cancelBet(id)} disabled={!canCancel} className="btn-coral py-2.5">
            <X className="w-4 h-4" /> Cancel
          </button>
        )}
      </div>

      {/* Quick amounts */}
      {!slot.placed && (
        <div className="grid grid-cols-4 gap-1 mb-3">
          {[100, 500, 1000, 5000].map((v) => (
            <button key={v} onClick={() => quickAmt(v)} className="btn-ghost py-1.5 text-xs tabular">
              {v >= 1000 ? `${v / 1000}K` : v}
            </button>
          ))}
        </div>
      )}

      {/* Auto cashout */}
      <div className={`rounded-xl border p-2.5 transition-colors ${autoEnabled ? 'border-neon-400/60 bg-neon-500/5' : 'border-borderline-900 bg-midnight-850'}`}>
        <div className="flex items-center gap-2">
          <button
            onClick={toggleAuto}
            className={`relative w-5 h-5 rounded-md border-2 transition-all flex-shrink-0 ${autoEnabled ? 'bg-neon-500 border-neon-400' : 'bg-slatepanel-800 border-borderline-800'}`}
            aria-pressed={autoEnabled}
            aria-label="Toggle auto cashout"
          >
            {autoEnabled && <Check className="w-3.5 h-3.5 text-white absolute inset-0 m-auto" strokeWidth={3.5} />}
          </button>
          <label className="text-xs font-semibold text-slate-300 flex-1">Auto Cash Out</label>
          <div className="flex items-center gap-1">
            <Zap className={`w-3.5 h-3.5 ${autoEnabled ? 'text-neon-400' : 'text-slate-600'}`} />
            <input
              type="number"
              value={autoTarget}
              onChange={(e) => setAutoTargetVal(e.target.value)}
              disabled={!autoEnabled}
              min={1.01}
              step={0.1}
              className="w-20 input py-1.5 tabular text-xs disabled:opacity-50"
              placeholder="2.00"
            />
            <span className="text-xs font-bold text-slate-400">x</span>
          </div>
        </div>
        {!autoEnabled && (
          <p className="text-[10px] text-slate-500 mt-1.5 pl-7">Disabled — tick the box to enable auto cashout at target multiplier.</p>
        )}
      </div>
    </div>
  );
}

export default function DualBetPanel() {
  return (
    <div className="grid grid-cols-2 gap-2 sm:gap-3">
      <BetConsole id="A" />
      <BetConsole id="B" />
    </div>
  );
}
