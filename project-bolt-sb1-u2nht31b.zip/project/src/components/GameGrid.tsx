import { Rocket, Bomb, Dice5, TrendingUp, ArrowRight } from 'lucide-react';
import type { Route } from './BottomNav';
import { useGameLogos } from '../lib/hooks';
import type { GameKey } from '../lib/gameLogos';

interface GameCardDef {
  key: Route;
  title: string;
  tag: string;
  icon: typeof Rocket;
  gradient: string;
  ring: string;
  badge?: string;
}

const games: GameCardDef[] = [
  {
    key: 'crash',
    title: 'Crash',
    tag: 'Real-time',
    icon: Rocket,
    gradient: 'from-neon-500/25 to-neon-700/5',
    ring: 'group-hover:border-neon-400',
    badge: 'HOT',
  },
  {
    key: 'mines',
    title: 'Mines',
    tag: 'Strategy',
    icon: Bomb,
    gradient: 'from-coral-500/25 to-coral-700/5',
    ring: 'group-hover:border-coral-400',
  },
  {
    key: 'ludo',
    title: 'Ludo',
    tag: 'Coming Soon',
    icon: Dice5,
    gradient: 'from-emeraldwin-500/20 to-emeraldwin-700/5',
    ring: 'group-hover:border-emeraldwin-400',
    badge: 'SOON',
  },
];

export default function GameGrid({ onPlay }: { onPlay: (r: Route) => void }) {
  const logos = useGameLogos();

  return (
    <section>
      <div className="flex items-center justify-between mb-3">
        <h2 className="font-display font-bold text-lg text-white">Games</h2>
        <button onClick={() => onPlay('games')} className="text-xs font-semibold text-neon-300 hover:text-neon-200 flex items-center gap-1">
          View all <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
      {/* Strict 3-column square grid — 1 row, 3 games */}
      <div className="grid grid-cols-3 gap-3">
        {games.map((g) => {
          const Icon = g.icon;
          const disabled = g.key === 'ludo';
          const logo = logos[g.key as GameKey];
          return (
            <button
              key={g.key}
              onClick={() => !disabled && onPlay(g.key)}
              disabled={disabled}
              className={`group relative aspect-square rounded-2xl border-2 border-borderline-900 bg-slatepanel-900 overflow-hidden transition-all duration-200 ${g.ring} ${disabled ? 'opacity-70' : 'hover:shadow-neon-glow active:scale-[0.97]'}`}
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${g.gradient} opacity-80`} />
              <div className="absolute inset-0 grid-shimmer animate-shimmer opacity-30" />
              {g.badge && (
                <span className={`absolute top-2 right-2 chip text-[9px] font-bold uppercase tracking-wide z-10 ${g.badge === 'HOT' ? 'bg-coral-500 text-white' : 'bg-amberx-500 text-midnight-900'}`}>
                  {g.badge}
                </span>
              )}
              <div className="absolute inset-0 grid place-items-center">
                {logo ? (
                  <img src={logo} alt={g.title} className="w-12 h-12 sm:w-14 sm:h-14 object-contain drop-shadow-lg group-hover:scale-110 transition-transform" />
                ) : (
                  <Icon className="w-10 h-10 sm:w-12 sm:h-12 text-white drop-shadow-lg group-hover:scale-110 transition-transform" strokeWidth={1.5} />
                )}
              </div>
              <div className="absolute bottom-0 inset-x-0 p-2 text-center bg-gradient-to-t from-midnight-900/90 to-transparent">
                <p className="font-display font-bold text-sm text-white leading-tight">{g.title}</p>
                <p className="text-[10px] text-slate-400 font-medium">{g.tag}</p>
              </div>
            </button>
          );
        })}
      </div>

      {/* Live stats strip */}
      <div className="mt-3 grid grid-cols-3 gap-3">
        <div className="panel-tight p-3 text-center">
          <p className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold">Online</p>
          <p className="tabular font-bold text-emeraldwin-400 text-lg">1,284</p>
        </div>
        <div className="panel-tight p-3 text-center">
          <p className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold">Top Win</p>
          <p className="tabular font-bold text-neon-300 text-lg flex items-center justify-center gap-1">
            <TrendingUp className="w-3.5 h-3.5" /> 48.2x
          </p>
        </div>
        <div className="panel-tight p-3 text-center">
          <p className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold">Paid Out</p>
          <p className="tabular font-bold text-amberx-400 text-lg">₹2.4M</p>
        </div>
      </div>
    </section>
  );
}
