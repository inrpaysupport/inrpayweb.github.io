import { useEffect, useState } from 'react';
import { bus, Topics } from '../lib/bus';
import { store } from '../lib/store';
import { useBalance, useNotifications } from '../lib/hooks';
import { Bell, Wallet, ChevronDown } from 'lucide-react';

function formatMoney(n: number) {
  return store.currency + n.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export default function Header({ onOpenNotifications, onOpenWallet }: { onOpenNotifications: () => void; onOpenWallet: () => void }) {
  const balance = useBalance();
  const notifications = useNotifications();
  const unread = notifications.filter((n) => !n.read).length;
  const [pulse, setPulse] = useState(false);

  useEffect(() => {
    const off = bus.on(Topics.Balance, () => {
      setPulse(true);
      setTimeout(() => setPulse(false), 400);
    });
    return off;
  }, []);

  return (
    <header className="sticky top-0 z-40 bg-midnight-900/85 backdrop-blur-xl border-b border-borderline-900">
      <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-neon-400 to-neon-600 grid place-items-center shadow-neon-glow">
            <span className="font-display font-extrabold text-white text-lg leading-none">M</span>
          </div>
          <div className="leading-none">
            <h1 className="font-display font-extrabold text-lg tracking-tight text-white">
              MIXO<span className="text-neon-400">WIN</span>
            </h1>
            <p className="text-[10px] text-slate-500 font-semibold tracking-widest uppercase mt-0.5">Premium Gaming</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenWallet}
            className={`group flex items-center gap-2 pl-2.5 pr-3 py-1.5 rounded-full bg-slatepanel-800 border border-borderline-900 hover:border-neon-400/60 transition-all ${pulse ? 'ring-2 ring-emeraldwin-500/40' : ''}`}
          >
            <span className="w-6 h-6 rounded-full bg-gradient-to-br from-emeraldwin-400 to-emeraldwin-600 grid place-items-center">
              <Wallet className="w-3.5 h-3.5 text-midnight-900" strokeWidth={2.5} />
            </span>
            <span className="tabular font-bold text-sm text-emeraldwin-400">{formatMoney(balance)}</span>
            <ChevronDown className="w-3.5 h-3.5 text-slate-500 group-hover:text-neon-400 transition-colors" />
          </button>

          <button
            onClick={onOpenNotifications}
            className="relative w-10 h-10 rounded-xl bg-slatepanel-800 border border-borderline-900 grid place-items-center hover:border-neon-400/60 transition-colors"
            aria-label="Notifications"
          >
            <Bell className="w-5 h-5 text-slate-300" />
            {unread > 0 && (
              <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-coral-500 text-white text-[10px] font-bold grid place-items-center border-2 border-midnight-900">
                {unread}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
}
