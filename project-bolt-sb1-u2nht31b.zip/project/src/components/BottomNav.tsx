import { Home, Gamepad2, Plus, Wallet, User } from 'lucide-react';

export type Route = 'home' | 'games' | 'deposit' | 'wallet' | 'profile' | 'crash' | 'mines' | 'ludo' | 'admin';

interface Props {
  route: Route;
  onNavigate: (r: Route) => void;
}

const items: { key: Route; label: string; icon: typeof Home }[] = [
  { key: 'home', label: 'Home', icon: Home },
  { key: 'games', label: 'Games', icon: Gamepad2 },
  { key: 'deposit', label: 'Deposit', icon: Plus },
  { key: 'wallet', label: 'Wallet', icon: Wallet },
  { key: 'profile', label: 'Profile', icon: User },
];

export default function BottomNav({ route, onNavigate }: Props) {
  return (
    <nav className="md:hidden fixed bottom-0 inset-x-0 z-40 safe-bottom">
      <div className="relative">
        {/* Floating Deposit FAB — raised -14px out of the bar */}
        <div className="absolute left-1/2 -translate-x-1/2 -top-3.5 z-20">
          <button
            onClick={() => onNavigate('deposit')}
            className="w-14 h-14 rounded-full bg-gradient-to-br from-neon-400 to-neon-600 grid place-items-center shadow-fab border-[3px] border-midnight-900 active:scale-95 transition-transform"
            aria-label="Deposit"
          >
            <Plus className="w-7 h-7 text-white" strokeWidth={3} />
          </button>
          <span className="absolute -bottom-5 left-1/2 -translate-x-1/2 text-[10px] font-bold text-neon-300 uppercase tracking-wider whitespace-nowrap">Deposit</span>
        </div>

        <div className="bg-slatepanel-900/95 backdrop-blur-xl border-t border-borderline-900 px-2 pt-2 pb-2.5">
          <div className="grid grid-cols-5 items-end">
            {items.map((it) => {
              const Icon = it.icon;
              const active = route === it.key || (it.key === 'home' && (route === 'crash' || route === 'mines' || route === 'ludo'));
              if (it.key === 'deposit') {
                return <div key={it.key} className="flex justify-center" />;
              }
              return (
                <button
                  key={it.key}
                  onClick={() => onNavigate(it.key)}
                  className="flex flex-col items-center gap-1 py-1 active:scale-95 transition-transform"
                >
                  <Icon
                    className={`w-5 h-5 transition-colors ${active ? 'text-neon-400' : 'text-slate-500'}`}
                    strokeWidth={active ? 2.5 : 2}
                  />
                  <span className={`text-[10px] font-semibold transition-colors ${active ? 'text-neon-300' : 'text-slate-500'}`}>
                    {it.label}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </nav>
  );
}
