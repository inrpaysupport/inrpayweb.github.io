import { useEffect, useState, useCallback } from 'react';
import { ArrowRight, Sparkles, Trophy, Gift } from 'lucide-react';

const slides = [
  {
    title: 'Welcome Bonus',
    subtitle: 'Get up to ₹15,000 on your first deposit',
    cta: 'Claim Now',
    icon: Gift,
    gradient: 'from-neon-500/30 via-neon-600/10 to-transparent',
    accent: 'text-neon-300',
  },
  {
    title: 'Crash Champions',
    subtitle: 'Top multipliers win weekly leaderboard prizes',
    cta: 'Play Crash',
    icon: Trophy,
    gradient: 'from-emeraldwin-500/25 via-emeraldwin-600/10 to-transparent',
    accent: 'text-emeraldwin-400',
  },
  {
    title: 'Mines Mania',
    subtitle: 'Clear the grid for massive gem multipliers',
    cta: 'Play Mines',
    icon: Sparkles,
    gradient: 'from-coral-500/25 via-coral-600/10 to-transparent',
    accent: 'text-coral-400',
  },
];

export default function SliderBanner({ onCta }: { onCta: (i: number) => void }) {
  const [idx, setIdx] = useState(0);

  const next = useCallback(() => setIdx((i) => (i + 1) % slides.length), []);

  useEffect(() => {
    const t = setInterval(next, 5000);
    return () => clearInterval(t);
  }, [next]);

  return (
    <div className="relative overflow-hidden rounded-2xl border border-borderline-900">
      <div className="flex transition-transform duration-500 ease-out" style={{ transform: `translateX(-${idx * 100}%)` }}>
        {slides.map((s, i) => {
          const Icon = s.icon;
          return (
            <div key={i} className="min-w-full h-40 sm:h-48 relative">
              <div className={`absolute inset-0 bg-gradient-to-br ${s.gradient}`} />
              <div className="absolute inset-0 bg-slatepanel-900" />
              <div className={`absolute inset-0 bg-gradient-to-br ${s.gradient}`} />
              <div className="absolute -right-6 -top-6 w-32 h-32 rounded-full bg-neon-500/10 blur-2xl" />
              <div className="relative h-full flex items-center justify-between px-5 sm:px-7">
                <div className="max-w-[70%]">
                  <div className={`inline-flex items-center gap-1.5 chip bg-midnight-900/60 border border-borderline-900 ${s.accent} mb-2`}>
                    <Icon className="w-3.5 h-3.5" />
                    <span className="uppercase tracking-wider text-[10px]">Promo</span>
                  </div>
                  <h2 className="font-display font-extrabold text-2xl sm:text-3xl text-white leading-tight">{s.title}</h2>
                  <p className="text-sm text-slate-300 mt-1">{s.subtitle}</p>
                  <button
                    onClick={() => onCta(i)}
                    className="btn-primary mt-3 px-4 py-2 text-sm"
                  >
                    {s.cta} <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
                <div className={`hidden sm:grid place-items-center w-20 h-20 rounded-2xl bg-midnight-900/60 border border-borderline-900 ${s.accent}`}>
                  <Icon className="w-10 h-10" strokeWidth={1.5} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
        {slides.map((_, i) => (
          <button
            key={i}
            onClick={() => setIdx(i)}
            className={`h-1.5 rounded-full transition-all ${i === idx ? 'w-6 bg-neon-400' : 'w-1.5 bg-slate-600'}`}
            aria-label={`Slide ${i + 1}`}
          />
        ))}
      </div>
    </div>
  );
}
