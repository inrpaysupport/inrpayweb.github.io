// Game logo registry — admin uploads custom logos (stored as data URLs in
// localStorage) which override the default lucide icons on game cards.
import { bus, Topics } from './bus';

const STORAGE_KEY = 'mixowin.gameLogos';

export type GameKey = 'crash' | 'mines' | 'ludo';

type LogoMap = Partial<Record<GameKey, string>>;

function load(): LogoMap {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function save(map: LogoMap) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(map));
  } catch {
    /* ignore quota */
  }
}

class GameLogoStore {
  private logos: LogoMap = load();

  get(key: GameKey): string | undefined {
    return this.logos[key];
  }

  all(): LogoMap {
    return { ...this.logos };
  }

  set(key: GameKey, dataUrl: string) {
    this.logos = { ...this.logos, [key]: dataUrl };
    save(this.logos);
    bus.emit(Topics.GameLogos, this.logos);
  }

  remove(key: GameKey) {
    const next = { ...this.logos };
    delete next[key];
    this.logos = next;
    save(this.logos);
    bus.emit(Topics.GameLogos, this.logos);
  }
}

export const gameLogos = new GameLogoStore();
