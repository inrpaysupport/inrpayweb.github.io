import { useEffect, useState } from 'react';
import { bus, Topics } from './bus';
import { store } from './store';
import type { AdminConfig, NotificationItem } from './store';
import type { CrashState, BetSlot } from './crashEngine';

export function useBus<T>(topic: string, initial: T): T {
  const [value, setValue] = useState<T>(initial);
  useEffect(() => {
    setValue(initial);
    return bus.on(topic, (p) => setValue(p as T));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [topic]);
  return value;
}

export function useBalance(): number {
  return useBus<number>(Topics.Balance, store.balance);
}

export function useNotifications(): NotificationItem[] {
  return useBus<NotificationItem[]>(Topics.Notification, store.notifications);
}

export function useAdminConfig(): AdminConfig {
  return useBus<AdminConfig>(Topics.AdminConfig, store.admin);
}

export function useCrashState(): CrashState {
  return useBus<CrashState>(Topics.CrashState, crashEngine.getState());
}

export function useCrashBets(): Record<'A' | 'B', BetSlot> {
  return useBus<Record<'A' | 'B', BetSlot>>(Topics.CrashTick, crashEngine.getBets());
}

export function useCrashHistory(): number[] {
  return useBus<number[]>(Topics.CrashHistory, crashEngine.getState().history);
}

// Re-export for convenience
import { crashEngine } from './crashEngine';
import { gameLogos } from './gameLogos';
import type { GameKey } from './gameLogos';

export { crashEngine };

export function useGameLogos(): Partial<Record<GameKey, string>> {
  return useBus<Partial<Record<GameKey, string>>>(Topics.GameLogos, gameLogos.all());
}
