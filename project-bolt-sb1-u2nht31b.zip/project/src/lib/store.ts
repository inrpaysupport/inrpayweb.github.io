import { bus, Topics } from './bus';

export interface AdminConfig {
  mode: 'AUTO' | 'MANUAL';
  targetWinProbability: number; // 0..100
  manualCrashPoint: number; // e.g. 2.5
  houseEdge: number; // %
}

export interface NotificationItem {
  id: string;
  title: string;
  body: string;
  kind: 'info' | 'success' | 'warn' | 'alert';
  ts: number;
  read: boolean;
}

class Store {
  balance = 10000;
  currency = '₹';
  notifications: NotificationItem[] = [];
  admin: AdminConfig = {
    mode: 'AUTO',
    targetWinProbability: 55,
    manualCrashPoint: 2.0,
    houseEdge: 4,
  };

  setBalance(next: number) {
    this.balance = Math.max(0, Math.round(next * 100) / 100);
    bus.emit(Topics.Balance, this.balance);
  }

  credit(amount: number) {
    this.setBalance(this.balance + amount);
  }

  debit(amount: number): boolean {
    if (amount > this.balance) return false;
    this.setBalance(this.balance - amount);
    return true;
  }

  pushNotification(n: Omit<NotificationItem, 'id' | 'ts' | 'read'>) {
    const item: NotificationItem = {
      ...n,
      id: Math.random().toString(36).slice(2),
      ts: Date.now(),
      read: false,
    };
    this.notifications = [item, ...this.notifications].slice(0, 30);
    bus.emit(Topics.Notification, this.notifications);
  }

  markAllRead() {
    this.notifications = this.notifications.map((n) => ({ ...n, read: true }));
    bus.emit(Topics.Notification, this.notifications);
  }

  setAdmin(patch: Partial<AdminConfig>) {
    this.admin = { ...this.admin, ...patch };
    bus.emit(Topics.AdminConfig, this.admin);
  }
}

export const store = new Store();

// Seed a welcome notification
store.pushNotification({
  title: 'Welcome to MIXOWIN',
  body: 'Your wallet is loaded with ₹10,000.00 demo balance. Good luck!',
  kind: 'success',
});
