// Lightweight in-memory pub/sub event bus — emulates Socket.io bi-directional
// real-time sync within the SPA. Components subscribe to topics and the engine
// emits state changes; this keeps the UI jitter-free and decoupled from game logic.

type Handler = (payload: unknown) => void;

class EventBus {
  private handlers = new Map<string, Set<Handler>>();

  on(topic: string, handler: Handler): () => void {
    if (!this.handlers.has(topic)) this.handlers.set(topic, new Set());
    this.handlers.get(topic)!.add(handler);
    return () => this.off(topic, handler);
  }

  off(topic: string, handler: Handler): void {
    this.handlers.get(topic)?.delete(handler);
  }

  emit(topic: string, payload?: unknown): void {
    this.handlers.get(topic)?.forEach((h) => {
      try {
        h(payload);
      } catch (err) {
        console.error('[bus] handler error', topic, err);
      }
    });
  }
}

export const bus = new EventBus();

export const Topics = {
  Balance: 'balance',
  CrashState: 'crash:state',
  CrashTick: 'crash:tick',
  CrashHistory: 'crash:history',
  MinesState: 'mines:state',
  Notification: 'notify',
  SecurityAlert: 'security:alert',
  AdminConfig: 'admin:config',
  Intercom: 'intercom:msg',
  GameLogos: 'game:logos',
} as const;
