import SliderBanner from '../components/SliderBanner';
import GameGrid from '../components/GameGrid';
import { useCrashHistory } from '../lib/hooks';
import type { Route } from '../components/BottomNav';
import { TrendingUp, ShieldCheck, Zap } from 'lucide-react';

export default function HomeView({ onNavigate }: { onNavigate: (r: Route) => void }) {
  const history = useCrashHistory();

  return (
    <div className="space-y-5 animate-fade-in">
      <SliderBanner onCta={(i) => onNavigate(i === 1 ? 'crash' : i === 2 ? 'mines' : 'deposit')} />

      <GameGrid onPlay={onNavigate} />

      {/* Live crash feed */}
      <section className="panel p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-neon-500/20 border border-neon-500/40 grid place-items-center">
              <TrendingUp className="w-4 h-4 text-neon-300" />
            </div>
            <h2 className="font-display font-bold text-base text-white">Live Crash Feed</h2>
          </div>
          <span className="chip bg-emeraldwin-500/15 border border-emeraldwin-500/40 text-emeraldwin-400 text-[10px]">
            <span className="w-1.5 h-1.5 rounded-full bg-emeraldwin-500 animate-ticker-blink" /> LIVE
          </span>
        </div>
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar">
          {history.length === 0 && <span className="text-xs text-slate-600">Waiting for first round…</span>}
          {history.map((m, i) => (
            <span
              key={i}
              className={`tabular chip text-xs font-bold flex-shrink-0 ${m >= 2 ? 'bg-emeraldwin-500/15 border border-emeraldwin-500/40 text-emeraldwin-400' : 'bg-coral-500/15 border border-coral-500/40 text-coral-400'}`}
            >
              {m.toFixed(2)}x
            </span>
          ))}
        </div>
      </section>

      {/* Trust strip */}
      <section className="grid grid-cols-3 gap-3">
        <div className="panel-tight p-3 text-center">
          <ShieldCheck className="w-5 h-5 text-emeraldwin-400 mx-auto mb-1" />
          <p className="text-[10px] text-slate-400 font-semibold">Provably Fair</p>
        </div>
        <div className="panel-tight p-3 text-center">
          <Zap className="w-5 h-5 text-neon-300 mx-auto mb-1" />
          <p className="text-[10px] text-slate-400 font-semibold">Instant Payouts</p>
        </div>
        <div className="panel-tight p-3 text-center">
          <ShieldCheck className="w-5 h-5 text-amberx-400 mx-auto mb-1" />
          <p className="text-[10px] text-slate-400 font-semibold">Secure Wallet</p>
        </div>
      </section>
    </div>
  );
}
