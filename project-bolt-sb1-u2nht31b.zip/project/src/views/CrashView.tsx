import { useEffect } from 'react';
import { crashEngine } from '../lib/crashEngine';
import { useCrashState, useCrashHistory } from '../lib/hooks';
import CrashCanvas from '../components/CrashCanvas';
import DualBetPanel from '../components/DualBetPanel';
import { Rocket, History } from 'lucide-react';

export default function CrashView() {
  const state = useCrashState();
  const history = useCrashHistory();

  useEffect(() => {
    crashEngine.start();
    return () => crashEngine.stop();
  }, []);

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-center gap-2">
        <div className="w-9 h-9 rounded-xl bg-neon-500/20 border border-neon-500/40 grid place-items-center">
          <Rocket className="w-5 h-5 text-neon-300" />
        </div>
        <div>
          <h1 className="font-display font-extrabold text-xl text-white leading-none">Crash</h1>
          <p className="text-xs text-slate-500">Round #{state.roundId} · Real-time multiplier</p>
        </div>
      </div>

      <CrashCanvas state={state} />

      {/* History strip */}
      <div className="panel p-3">
        <div className="flex items-center gap-2 mb-2">
          <History className="w-4 h-4 text-slate-500" />
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Recent Rounds</span>
        </div>
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar">
          {history.length === 0 && <span className="text-xs text-slate-600">No rounds yet</span>}
          {history.map((m, i) => (
            <span
              key={i}
              className={`tabular chip text-xs font-bold flex-shrink-0 ${m >= 2 ? 'bg-emeraldwin-500/15 border border-emeraldwin-500/40 text-emeraldwin-400' : 'bg-coral-500/15 border border-coral-500/40 text-coral-400'}`}
            >
              {m.toFixed(2)}x
            </span>
          ))}
        </div>
      </div>

      <DualBetPanel />

      <p className="text-[11px] text-slate-600 text-center px-4">
        Place bets during the countdown. Cash out before the rocket busts. Auto cashout triggers automatically at your target multiplier.
      </p>
    </div>
  );
}
