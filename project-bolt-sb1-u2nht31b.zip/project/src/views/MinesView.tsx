import { useState } from 'react';
import { minesEngine } from '../lib/minesEngine';
import { useBus } from '../lib/hooks';
import { Topics } from '../lib/bus';
import type { MinesState } from '../lib/minesEngine';
import { store } from '../lib/store';
import { Bomb, Gem, Flag, Play, HandCoins } from 'lucide-react';

function Cell({ index, state, onReveal }: { index: number; state: MinesState; onReveal: (i: number) => void }) {
  const revealed = state.revealed[index];
  const cell = state.grid[index];
  const isMine = cell === 'mine';
  const isGem = cell === 'gem';

  return (
    <button
      onClick={() => onReveal(index)}
      disabled={revealed || !state.active}
      className={`relative aspect-square rounded-xl border transition-all duration-200 ${
        revealed
          ? isMine
            ? 'bg-coral-500/20 border-coral-500/60'
            : 'bg-emeraldwin-500/15 border-emeraldwin-500/50'
          : 'bg-slatepanel-800 border-borderline-900 hover:border-neon-400/60 hover:bg-slatepanel-700 active:scale-95'
      } ${!revealed && state.active ? 'cursor-pointer' : 'cursor-default'}`}
    >
      {revealed && isGem && (
        <div className="absolute inset-0 grid place-items-center animate-gem-pop">
          <Gem className="w-6 h-6 sm:w-7 sm:h-7 text-emeraldwin-400 drop-shadow-[0_0_8px_rgba(0,255,136,0.5)]" />
        </div>
      )}
      {revealed && isMine && (
        <div className="absolute inset-0 grid place-items-center animate-mine-blast">
          <Bomb className="w-6 h-6 sm:w-7 sm:h-7 text-coral-500 drop-shadow-[0_0_8px_rgba(255,51,102,0.5)]" />
        </div>
      )}
      {!revealed && state.active && (
        <div className="absolute inset-0 grid place-items-center">
          <div className="w-2 h-2 rounded-full bg-slate-600 group-hover:bg-neon-400" />
        </div>
      )}
    </button>
  );
}

export default function MinesView() {
  const state = useBus<MinesState>(Topics.MinesState, minesEngine.getState());
  const [stake, setStake] = useState('100');
  const [mines, setMines] = useState(3);

  const start = () => {
    minesEngine.setStake(parseFloat(stake) || 100);
    minesEngine.setMineCount(mines);
    const res = minesEngine.start();
    if (!res.ok) store.pushNotification({ title: 'Mines failed', body: res.reason || '', kind: 'warn' });
  };

  const reveal = (i: number) => minesEngine.reveal(i);
  const cashout = () => {
    const res = minesEngine.cashOut();
    if (!res.ok) store.pushNotification({ title: 'Cashout failed', body: res.reason || '', kind: 'warn' });
  };

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-center gap-2">
        <div className="w-9 h-9 rounded-xl bg-coral-500/20 border border-coral-500/40 grid place-items-center">
          <Bomb className="w-5 h-5 text-coral-400" />
        </div>
        <div>
          <h1 className="font-display font-extrabold text-xl text-white leading-none">Mines</h1>
          <p className="text-xs text-slate-500">5×5 grid · {mines} mines hidden</p>
        </div>
      </div>

      {/* Grid */}
      <div className="panel p-3 sm:p-4">
        <div className="grid grid-cols-5 gap-2 sm:gap-2.5">
          {Array.from({ length: 25 }, (_, i) => (
            <Cell key={i} index={i} state={state} onReveal={reveal} />
          ))}
        </div>
      </div>

      {/* Controls / bet section */}
      <div className="panel p-3 sm:p-4">
        <div className="grid grid-cols-2 gap-3 mb-3">
          <div>
            <label className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold">Stake</label>
            <div className="relative mt-1">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 font-bold text-sm">{store.currency}</span>
              <input
                type="number"
                value={stake}
                onChange={(e) => setStake(e.target.value)}
                disabled={state.active}
                min={1}
                className="input pl-7 tabular"
              />
            </div>
          </div>
          <div>
            <label className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold">Mines</label>
            <div className="relative mt-1">
              <Flag className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input
                type="number"
                value={mines}
                onChange={(e) => setMines(Math.max(1, Math.min(24, parseInt(e.target.value) || 1)))}
                disabled={state.active}
                min={1}
                max={24}
                className="input pl-9 tabular"
              />
            </div>
          </div>
        </div>

        {/* Multiplier display */}
        <div className="flex items-center justify-between mb-3 px-1">
          <div>
            <p className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold">Current</p>
            <p className="tabular font-display font-extrabold text-2xl text-emeraldwin-400">{state.currentMultiplier.toFixed(2)}x</p>
          </div>
          <div className="text-right">
            <p className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold">Next Gem</p>
            <p className="tabular font-bold text-lg text-neon-300">{state.nextMultiplier.toFixed(2)}x</p>
          </div>
          <div className="text-right">
            <p className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold">Gems</p>
            <p className="tabular font-bold text-lg text-white">{state.gemsFound}</p>
          </div>
        </div>

        {!state.active ? (
          <button onClick={start} className="btn-primary w-full py-3">
            <Play className="w-4 h-4" /> Start Round
          </button>
        ) : (
          <div className="grid grid-cols-2 gap-2">
            <button onClick={cashout} disabled={state.gemsFound === 0 || state.busted || state.cashedOut} className="btn-emerald py-3">
              <HandCoins className="w-4 h-4" />
              Cash Out {store.currency}{state.gemsFound > 0 ? (state.stake * state.currentMultiplier).toFixed(2) : '0.00'}
            </button>
            <div className="btn-ghost py-3 justify-center text-sm text-slate-400">
              {state.busted ? 'Round lost' : state.cashedOut ? 'Cashed out' : 'Pick a tile'}
            </div>
          </div>
        )}
      </div>

      <p className="text-[11px] text-slate-600 text-center px-4">
        Reveal gems to grow your multiplier. Hit a mine and you lose your stake. Cash out anytime to lock in winnings.
      </p>
    </div>
  );
}
