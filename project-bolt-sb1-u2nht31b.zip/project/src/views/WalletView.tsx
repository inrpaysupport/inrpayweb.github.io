import { useState } from 'react';
import { useBalance } from '../lib/hooks';
import { store } from '../lib/store';
import { ArrowLeft, ArrowDownLeft, ArrowUpRight, Wallet as WalletIcon, Plus, Minus } from 'lucide-react';
import type { Route } from '../components/BottomNav';

interface Txn {
  id: string;
  kind: 'deposit' | 'withdraw' | 'bet' | 'win' | 'bonus';
  amount: number;
  ts: number;
  note: string;
}

const initialTxns: Txn[] = [
  { id: 't1', kind: 'deposit', amount: 10000, ts: Date.now() - 3600000, note: 'Welcome bonus' },
  { id: 't2', kind: 'win', amount: 480, ts: Date.now() - 1800000, note: 'Crash @ 4.80x' },
  { id: 't3', kind: 'bet', amount: -100, ts: Date.now() - 1700000, note: 'Mines stake' },
  { id: 't4', kind: 'win', amount: 220, ts: Date.now() - 1600000, note: 'Mines cashout @ 2.20x' },
];

const kindStyle: Record<Txn['kind'], { color: string; icon: typeof Plus; label: string }> = {
  deposit: { color: 'text-emeraldwin-400', icon: ArrowDownLeft, label: 'Deposit' },
  withdraw: { color: 'text-coral-400', icon: ArrowUpRight, label: 'Withdraw' },
  bet: { color: 'text-coral-400', icon: Minus, label: 'Bet' },
  win: { color: 'text-emeraldwin-400', icon: Plus, label: 'Win' },
  bonus: { color: 'text-neon-300', icon: Plus, label: 'Bonus' },
};

export default function WalletView({ onNavigate }: { onNavigate: (r: Route) => void }) {
  const balance = useBalance();
  const [txns] = useState<Txn[]>(initialTxns);

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-center gap-2">
        <button onClick={() => onNavigate('home')} className="md:hidden w-9 h-9 rounded-xl bg-slatepanel-800 border border-borderline-900 grid place-items-center">
          <ArrowLeft className="w-5 h-5 text-slate-300" />
        </button>
        <div>
          <h1 className="font-display font-extrabold text-xl text-white">Wallet</h1>
          <p className="text-xs text-slate-500">Manage your balance & transactions</p>
        </div>
      </div>

      {/* Balance card */}
      <div className="relative panel p-5 overflow-hidden">
        <div className="absolute -right-8 -top-8 w-40 h-40 rounded-full bg-neon-500/10 blur-3xl" />
        <div className="relative">
          <div className="flex items-center gap-2 text-slate-400 text-xs font-semibold uppercase tracking-wider">
            <WalletIcon className="w-4 h-4" /> Total Balance
          </div>
          <p className="tabular font-display font-extrabold text-4xl text-white mt-2">
            {store.currency}{balance.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </p>
          <div className="flex gap-2 mt-4">
            <button onClick={() => onNavigate('deposit')} className="btn-primary flex-1 py-2.5">
              <ArrowDownLeft className="w-4 h-4" /> Deposit
            </button>
            <button onClick={() => store.pushNotification({ title: 'Withdrawal queued', body: 'Withdrawals processed within 24h.', kind: 'info' })} className="btn-ghost flex-1 py-2.5">
              <ArrowUpRight className="w-4 h-4" /> Withdraw
            </button>
          </div>
        </div>
      </div>

      {/* Transactions */}
      <div className="panel p-4">
        <h2 className="font-display font-bold text-base text-white mb-3">Recent Transactions</h2>
        <div className="space-y-2">
          {txns.map((t) => {
            const s = kindStyle[t.kind];
            const Icon = s.icon;
            return (
              <div key={t.id} className="flex items-center gap-3 p-2.5 rounded-xl bg-midnight-850 border border-borderline-900">
                <div className={`w-9 h-9 rounded-lg grid place-items-center ${t.amount >= 0 ? 'bg-emeraldwin-500/15' : 'bg-coral-500/15'}`}>
                  <Icon className={`w-4 h-4 ${s.color}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-white truncate">{t.note}</p>
                  <p className="text-[11px] text-slate-500">{s.label} · {new Date(t.ts).toLocaleTimeString()}</p>
                </div>
                <p className={`tabular font-bold text-sm ${s.color}`}>
                  {t.amount >= 0 ? '+' : ''}{store.currency}{Math.abs(t.amount).toFixed(2)}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
