import { Rocket, Bomb, Dice5, ArrowLeft, Search } from 'lucide-react';
import { useState } from 'react';
import type { Route } from '../components/BottomNav';
import { useGameLogos } from '../lib/hooks';
import type { GameKey } from '../lib/gameLogos';

interface GameDef {
  key: Route;
  title: string;
  desc: string;
  icon: typeof Rocket;
  gradient: string;
  ring: string;
  badge?: string;
  players: string;
}

const allGames: GameDef[] = [
  { key: 'crash', title: 'Crash', desc: 'Real-time multiplier rocket. Cash out before it busts.', icon: Rocket, gradient: 'from-neon-500/25 to-neon-700/5', ring: 'hover:border-neon-400', badge: 'HOT', players: '842 online' },
  { key: 'mines', title: 'Mines', desc: '5×5 grid sweep. Find gems, avoid mines.', icon: Bomb, gradient: 'from-coral-500/25 to-coral-700/5', ring: 'hover:border-coral-400', players: '318 online' },
  { key: 'ludo', title: 'Ludo', desc: 'Classic board game. Coming soon.', icon: Dice5, gradient: 'from-emeraldwin-500/20 to-emeraldwin-700/5', ring: 'hover:border-emeraldwin-400', badge: 'SOON', players: 'Pre-register' },
];

export default function GamesView({ onNavigate }: { onNavigate: (r: Route) => void }) {
  const [q, setQ] = useState('');
  const logos = useGameLogos();
  const filtered = allGames.filter((g) => g.title.toLowerCase().includes(q.toLowerCase()));

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-center gap-2">
        <button onClick={() => onNavigate('home')} className="md:hidden w-9 h-9 rounded-xl bg-slatepanel-800 border border-borderline-900 grid place-items-center">
          <ArrowLeft className="w-5 h-5 text-slate-300" />
        </button>
        <div>
          <h1 className="font-display font-extrabold text-xl text-white">All Games</h1>
          <p className="text-xs text-slate-500">{filtered.length} games available</p>
        </div>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search games…" className="input pl-10" />
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {filtered.map((g) => {
          const Icon = g.icon;
          const disabled = g.key === 'ludo';
          const logo = logos[g.key as GameKey];
          return (
            <button
              key={g.key}
              onClick={() => !disabled && onNavigate(g.key)}
              disabled={disabled}
              className={`group panel p-4 text-left transition-all ${g.ring} ${disabled ? 'opacity-70' : 'hover:shadow-neon-glow active:scale-[0.98]'}`}
            >
              <div className="flex items-start justify-between mb-3">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${g.gradient} border border-borderline-900 grid place-items-center overflow-hidden`}>
                  {logo ? (
                    <img src={logo} alt={g.title} className="w-8 h-8 object-contain" />
                  ) : (
                    <Icon className="w-6 h-6 text-white" strokeWidth={1.5} />
                  )}
                </div>
                {g.badge && (
                  <span className={`chip text-[9px] font-bold uppercase ${g.badge === 'HOT' ? 'bg-coral-500 text-white' : 'bg-amberx-500 text-midnight-900'}`}>
                    {g.badge}
                  </span>
                )}
              </div>
              <h3 className="font-display font-bold text-white">{g.title}</h3>
              <p className="text-xs text-slate-400 mt-1 line-clamp-2">{g.desc}</p>
              <p className="text-[10px] text-emeraldwin-400 font-semibold mt-2">{g.players}</p>
            </button>
          );
        })}
      </div>
    </div>
  );
}
