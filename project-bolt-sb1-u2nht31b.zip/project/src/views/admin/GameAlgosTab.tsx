import { useState, useRef } from 'react';
import { useAdminConfig, useGameLogos } from '../../lib/hooks';
import { store } from '../../lib/store';
import { gameLogos } from '../../lib/gameLogos';
import type { GameKey } from '../../lib/gameLogos';
import { Shield, Sliders, Target, Cpu, Zap, Upload, Image as ImageIcon, Trash2, Rocket, Bomb, Dice5 } from 'lucide-react';

const gameMeta: { key: GameKey; label: string; icon: typeof Rocket }[] = [
  { key: 'crash', label: 'Crash', icon: Rocket },
  { key: 'mines', label: 'Mines', icon: Bomb },
  { key: 'ludo', label: 'Ludo', icon: Dice5 },
];

export default function GameAlgosTab() {
  const cfg = useAdminConfig();
  const logos = useGameLogos();
  const [manual, setManual] = useState(String(cfg.manualCrashPoint));
  const fileRefs = useRef<Record<string, HTMLInputElement | null>>({});

  const setMode = (mode: 'AUTO' | 'MANUAL') => store.setAdmin({ mode });
  const setProb = (v: number) => store.setAdmin({ targetWinProbability: v });
  const setEdge = (v: number) => store.setAdmin({ houseEdge: v });
  const setManualCrash = () => store.setAdmin({ manualCrashPoint: Math.max(1.01, parseFloat(manual) || 1.01) });

  const onUpload = (key: GameKey, file: File) => {
    if (!file.type.startsWith('image/')) {
      store.pushNotification({ title: 'Invalid file', body: 'Please upload an image file.', kind: 'warn' });
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      gameLogos.set(key, reader.result as string);
      store.pushNotification({ title: 'Logo updated', body: `${key} logo uploaded successfully.`, kind: 'success' });
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-4">
      <div>
        <h2 className="font-display font-bold text-lg text-white">Algorithmic Game Modifiers</h2>
        <p className="text-xs text-slate-500">Control Crash round outcomes in real-time.</p>
      </div>

      {/* Game Logo Upload */}
      <div className="panel p-4">
        <h3 className="font-display font-bold text-sm text-white mb-1 flex items-center gap-2">
          <ImageIcon className="w-4 h-4 text-neon-300" /> Game Logo Upload
        </h3>
        <p className="text-xs text-slate-500 mb-3">Upload custom logos for game cards. Replaces default icons instantly.</p>
        <div className="grid grid-cols-3 gap-3">
          {gameMeta.map((g) => {
            const Icon = g.icon;
            const logo = logos[g.key];
            return (
              <div key={g.key} className="panel-tight p-3 text-center">
                <div className="w-16 h-16 mx-auto rounded-xl bg-slatepanel-800 border border-borderline-900 grid place-items-center overflow-hidden mb-2">
                  {logo ? (
                    <img src={logo} alt={g.label} className="w-full h-full object-contain" />
                  ) : (
                    <Icon className="w-8 h-8 text-slate-500" strokeWidth={1.5} />
                  )}
                </div>
                <p className="text-xs font-semibold text-white mb-2">{g.label}</p>
                <div className="flex gap-1.5 justify-center">
                  <button
                    onClick={() => fileRefs.current[g.key]?.click()}
                    className="btn-ghost px-2.5 py-1.5 text-xs"
                  >
                    <Upload className="w-3.5 h-3.5" /> Upload
                  </button>
                  {logo && (
                    <button
                      onClick={() => gameLogos.remove(g.key)}
                      className="w-8 h-8 rounded-lg bg-coral-500/15 border border-coral-500/40 grid place-items-center"
                    >
                      <Trash2 className="w-3.5 h-3.5 text-coral-400" />
                    </button>
                  )}
                </div>
                <input
                  ref={(el) => { fileRefs.current[g.key] = el; }}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => e.target.files?.[0] && onUpload(g.key, e.target.files[0])}
                />
              </div>
            );
          })}
        </div>
      </div>


      {/* Mode switch */}
      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={() => setMode('AUTO')}
          className={`panel p-4 text-left transition-all ${cfg.mode === 'AUTO' ? 'border-neon-400 ring-1 ring-neon-400/40' : 'opacity-70 hover:opacity-100'}`}
        >
          <div className="flex items-center gap-2 mb-2">
            <Shield className={`w-5 h-5 ${cfg.mode === 'AUTO' ? 'text-neon-300' : 'text-slate-500'}`} />
            <span className="font-display font-bold text-white">Automated Shield</span>
          </div>
          <p className="text-xs text-slate-400">Mathematical target win-probability safeguards system revenue.</p>
          {cfg.mode === 'AUTO' && <span className="chip bg-neon-500/15 border border-neon-500/40 text-neon-300 text-[10px] mt-2">Active</span>}
        </button>
        <button
          onClick={() => setMode('MANUAL')}
          className={`panel p-4 text-left transition-all ${cfg.mode === 'MANUAL' ? 'border-coral-400 ring-1 ring-coral-400/40' : 'opacity-70 hover:opacity-100'}`}
        >
          <div className="flex items-center gap-2 mb-2">
            <Cpu className={`w-5 h-5 ${cfg.mode === 'MANUAL' ? 'text-coral-400' : 'text-slate-500'}`} />
            <span className="font-display font-bold text-white">Manual Override</span>
          </div>
          <p className="text-xs text-slate-400">Hardcode an exact termination crash multiplier.</p>
          {cfg.mode === 'MANUAL' && <span className="chip bg-coral-500/15 border border-coral-500/40 text-coral-400 text-[10px] mt-2">Active</span>}
        </button>
      </div>

      {/* AUTO controls */}
      {cfg.mode === 'AUTO' && (
        <div className="panel p-5 space-y-5 animate-fade-in">
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-semibold text-white flex items-center gap-2">
                <Sliders className="w-4 h-4 text-neon-300" /> Target Win Probability
              </label>
              <span className="tabular font-display font-extrabold text-2xl text-neon-300">{cfg.targetWinProbability}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              value={cfg.targetWinProbability}
              onChange={(e) => setProb(parseInt(e.target.value))}
              className="w-full accent-neon-400 h-2"
            />
            <div className="flex justify-between text-[10px] text-slate-500 mt-1">
              <span>0% (house max)</span>
              <span>100% (player max)</span>
            </div>
            <p className="text-[11px] text-slate-500 mt-2">
              At {cfg.targetWinProbability}% win probability, the engine biases bust-point distribution to protect revenue while keeping rounds fair.
            </p>
          </div>
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-semibold text-white flex items-center gap-2">
                <Zap className="w-4 h-4 text-amberx-400" /> House Edge
              </label>
              <span className="tabular font-bold text-amberx-400">{cfg.houseEdge}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={15}
              value={cfg.houseEdge}
              onChange={(e) => setEdge(parseInt(e.target.value))}
              className="w-full accent-amberx-400 h-2"
            />
          </div>
        </div>
      )}

      {/* MANUAL controls */}
      {cfg.mode === 'MANUAL' && (
        <div className="panel p-5 animate-fade-in">
          <label className="text-sm font-semibold text-white flex items-center gap-2 mb-2">
            <Target className="w-4 h-4 text-coral-400" /> Termination Crash Multiplier
          </label>
          <div className="flex gap-2">
            <input
              type="number"
              value={manual}
              onChange={(e) => setManual(e.target.value)}
              min={1.01}
              step={0.1}
              className="input tabular"
            />
            <button onClick={setManualCrash} className="btn-coral px-4">Apply</button>
          </div>
          <p className="text-[11px] text-slate-500 mt-2">Next round will bust exactly at {cfg.manualCrashPoint.toFixed(2)}x.</p>
        </div>
      )}
    </div>
  );
}
