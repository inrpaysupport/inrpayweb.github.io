import { useState } from 'react';
import { security, getDeviceToken, getClientIP } from '../../lib/security';
import { store } from '../../lib/store';
import { Users, Plus, Minus, ShieldAlert, Search } from 'lucide-react';

interface UserProfile {
  id: string;
  account: string;
  deviceToken: string;
  ip: string;
  balance: number;
  status: 'active' | 'flagged';
  joined: number;
}

const seedUsers: UserProfile[] = [
  { id: 'u1', account: 'player_a1b2', deviceToken: 'dev_' + getDeviceToken().slice(4, 12), ip: getClientIP(), balance: 4820.5, status: 'active', joined: Date.now() - 86400000 },
  { id: 'u2', account: 'highroller_99', deviceToken: 'dev_7f3a9c21', ip: '10.0.45.12', balance: 28400.0, status: 'active', joined: Date.now() - 172800000 },
  { id: 'u3', account: 'newbie_x7', deviceToken: 'dev_2b8e1f04', ip: '10.0.45.12', balance: 320.0, status: 'flagged', joined: Date.now() - 3600000 },
  { id: 'u4', account: 'crash_king', deviceToken: 'dev_9c4d2a77', ip: '10.0.88.4', balance: 12450.75, status: 'active', joined: Date.now() - 432000000 },
  { id: 'u5', account: 'mines_pro', deviceToken: 'dev_2b8e1f04', ip: '10.0.45.99', balance: 890.25, status: 'flagged', joined: Date.now() - 7200000 },
];

export default function UsersTab() {
  const [users, setUsers] = useState<UserProfile[]>(seedUsers);
  const [q, setQ] = useState('');
  const [adjustId, setAdjustId] = useState<string | null>(null);
  const [amount, setAmount] = useState('');

  const filtered = users.filter((u) => u.account.includes(q.toLowerCase()) || u.ip.includes(q) || u.deviceToken.includes(q.toLowerCase()));

  const adjust = (id: string, dir: 'credit' | 'debit') => {
    const amt = parseFloat(amount) || 0;
    if (amt <= 0) return;
    setUsers((prev) => prev.map((u) => u.id === id ? { ...u, balance: dir === 'credit' ? u.balance + amt : Math.max(0, u.balance - amt) } : u));
    const u = users.find((x) => x.id === id);
    store.pushNotification({ title: `${dir === 'credit' ? 'Credited' : 'Debited'} ${u?.account}`, body: `₹${amt.toFixed(2)} ${dir === 'credit' ? 'added' : 'removed'}.`, kind: dir === 'credit' ? 'success' : 'warn' });
    setAdjustId(null);
    setAmount('');
  };

  return (
    <div className="space-y-4">
      <div>
        <h2 className="font-display font-bold text-lg text-white">CRM Profile & Wallet Grid</h2>
        <p className="text-xs text-slate-500">Map client sessions, device tokens & IP nodes. Flag multi-account abuse.</p>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search account, IP, or device token…" className="input pl-10" />
      </div>

      <div className="panel overflow-hidden">
        <div className="overflow-x-auto scrollbar-thin">
          <table className="w-full text-sm">
            <thead className="bg-midnight-850 border-b border-borderline-900">
              <tr className="text-left text-[10px] uppercase tracking-wider text-slate-500 font-semibold">
                <th className="p-3">Account</th>
                <th className="p-3">Device Token</th>
                <th className="p-3">IP Node</th>
                <th className="p-3 text-right">Balance</th>
                <th className="p-3">Status</th>
                <th className="p-3 text-right">Adjust</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-borderline-900">
              {filtered.map((u) => (
                <tr key={u.id} className="hover:bg-slatepanel-800/50">
                  <td className="p-3 font-semibold text-white">{u.account}</td>
                  <td className="p-3 font-mono text-[11px] text-slate-400">{u.deviceToken}</td>
                  <td className="p-3 font-mono text-[11px] text-slate-400">{u.ip}</td>
                  <td className="p-3 text-right tabular font-bold text-emeraldwin-400">₹{u.balance.toFixed(2)}</td>
                  <td className="p-3">
                    {u.status === 'flagged' ? (
                      <span className="chip bg-coral-500/15 border border-coral-500/40 text-coral-400 text-[10px]">
                        <ShieldAlert className="w-3 h-3" /> Flagged
                      </span>
                    ) : (
                      <span className="chip bg-emeraldwin-500/15 border border-emeraldwin-500/40 text-emeraldwin-400 text-[10px]">Active</span>
                    )}
                  </td>
                  <td className="p-3 text-right">
                    {adjustId === u.id ? (
                      <div className="flex items-center gap-1 justify-end">
                        <input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="Amt" className="w-20 input py-1 text-xs tabular" />
                        <button onClick={() => adjust(u.id, 'credit')} className="w-7 h-7 rounded-lg bg-emeraldwin-500/20 border border-emeraldwin-500/40 grid place-items-center"><Plus className="w-3.5 h-3.5 text-emeraldwin-400" /></button>
                        <button onClick={() => adjust(u.id, 'debit')} className="w-7 h-7 rounded-lg bg-coral-500/20 border border-coral-500/40 grid place-items-center"><Minus className="w-3.5 h-3.5 text-coral-400" /></button>
                      </div>
                    ) : (
                      <button onClick={() => setAdjustId(u.id)} className="text-xs font-semibold text-neon-300 hover:text-neon-200">Adjust</button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="panel p-4">
        <h3 className="font-display font-bold text-sm text-white mb-2 flex items-center gap-2"><Users className="w-4 h-4 text-neon-300" /> Active Sessions</h3>
        <p className="text-xs text-slate-500">{security.listSessions().length} session(s) registered on the socket layer.</p>
      </div>
    </div>
  );
}
