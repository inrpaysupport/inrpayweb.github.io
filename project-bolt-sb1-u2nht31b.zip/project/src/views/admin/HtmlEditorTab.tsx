import { useState } from 'react';
import { Code2, Eye, Save, FileCode } from 'lucide-react';
import { store } from '../../lib/store';

const defaultHtml = `<!-- Transaction Email Template -->
<div style="font-family: Inter, sans-serif; max-width: 480px; margin: 0 auto; background: #0f1225; color: #fff; border-radius: 16px; overflow: hidden;">
  <div style="background: linear-gradient(135deg, #b15eff, #9a3eff); padding: 24px; text-align: center;">
    <h1 style="margin: 0; font-size: 22px;">MIXOWIN</h1>
    <p style="margin: 4px 0 0; opacity: 0.9;">Transaction Confirmation</p>
  </div>
  <div style="padding: 24px;">
    <p>Hi {{username}},</p>
    <p>Your transaction of <strong style="color: #00ff88;">{{amount}}</strong> has been processed.</p>
    <p>New balance: <strong>{{balance}}</strong></p>
    <a href="{{link}}" style="display: inline-block; background: #b15eff; color: #fff; padding: 10px 20px; border-radius: 8px; text-decoration: none; margin-top: 12px;">View Receipt</a>
  </div>
</div>`;

export default function HtmlEditorTab() {
  const [code, setCode] = useState(defaultHtml);
  const [preview, setPreview] = useState(false);

  const save = () => store.pushNotification({ title: 'Template saved', body: 'HTML email template compiled and stored.', kind: 'success' });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-display font-bold text-lg text-white">HTML Campaign Editor</h2>
          <p className="text-xs text-slate-500">Compile custom transaction markup templates.</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setPreview(!preview)} className="btn-ghost px-3 py-2 text-sm">
            {preview ? <Code2 className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            {preview ? 'Edit' : 'Preview'}
          </button>
          <button onClick={save} className="btn-primary px-3 py-2 text-sm"><Save className="w-4 h-4" /> Save</button>
        </div>
      </div>

      {preview ? (
        <div className="panel p-4">
          <div className="flex items-center gap-2 mb-3 text-slate-500 text-xs font-semibold uppercase tracking-wider">
            <Eye className="w-4 h-4" /> Rendered Preview
          </div>
          <div className="rounded-xl overflow-hidden border border-borderline-900 bg-white" dangerouslySetInnerHTML={{ __html: code }} />
        </div>
      ) : (
        <div className="panel p-1">
          <div className="flex items-center gap-2 px-3 py-2 border-b border-borderline-900 text-slate-500 text-xs font-semibold uppercase tracking-wider">
            <FileCode className="w-4 h-4" /> template.html
          </div>
          <textarea
            value={code}
            onChange={(e) => setCode(e.target.value)}
            spellCheck={false}
            className="w-full h-80 bg-midnight-850 p-4 font-mono text-xs text-emeraldwin-300 outline-none resize-none scrollbar-thin"
          />
        </div>
      )}

      <div className="panel p-4">
        <h3 className="font-display font-bold text-sm text-white mb-2">Available Variables</h3>
        <div className="flex flex-wrap gap-2">
          {['{{username}}', '{{amount}}', '{{balance}}', '{{link}}', '{{date}}', '{{txn_id}}'].map((v) => (
            <span key={v} className="chip bg-midnight-850 border border-borderline-900 text-neon-300 font-mono text-xs">{v}</span>
          ))}
        </div>
      </div>
    </div>
  );
}
