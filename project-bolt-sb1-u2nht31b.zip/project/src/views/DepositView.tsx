import { useState } from 'react';
import { useBalance } from '../lib/hooks';
import { store } from '../lib/store';
import { ArrowLeft, CreditCard, Smartphone, Bitcoin, Landmark, ShieldCheck } from 'lucide-react';
import type { Route } from '../components/BottomNav';

const methods = [
  { id: 'upi', label: 'UPI', desc: 'Instant · 0 fee', icon: Smartphone, accent: 'text-neon-300' },
  { id: 'card', label: 'Card', desc: 'Visa / Mastercard', icon: CreditCard, accent: 'text-emeraldwin-400' },
  { id: 'bank', label: 'Bank', desc: '1-3 business days', icon: Landmark, accent: 'text-amberx-400' },
  { id: 'crypto', label: 'Crypto', desc: 'USDT / BTC', icon: Bitcoin, accent: 'text-neon-300' },
];

const quickAmounts = [500, 1000, 2500, 5000, 10000, 25000];

export default function DepositView({ onNavigate }: { onNavigate: (r: Route) => void }) {
  const balance = useBalance();
  const [amount, setAmount] = useState('1000');
  const [method, setMethod] = useState('upi');

  const deposit = () => {
    const amt = parseFloat(amount) || 0;
    if (amt <= 0) return;
    store.credit(amt);
    store.pushNotification({ title: 'Deposit successful', body: `${store.currency}${amt.toFixed(2)} added to your wallet.`, kind: 'success' });
    onNavigate('wallet');
  };

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-center gap-2">
        <button onClick={() => onNavigate('home')} className="md:hidden w-9 h-9 rounded-xl bg-slatepanel-800 border border-borderline-900 grid place-items-center">
          <ArrowLeft className="w-5 h-5 text-slate-300" />
        </button>
        <div>
          <h1 className="font-display font-extrabold text-xl text-white">Deposit</h1>
          <p className="text-xs text-slate-500">Balance: {store.currency}{balance.toFixed(2)}</p>
        </div>
      </div>

      {/* Amount */}
      <div className="panel p-5">
        <label className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold">Amount</label>
        <div className="relative mt-1.5">
          <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-xl">{store.currency}</span>
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            min={1}
            className="input pl-10 py-4 text-2xl font-display font-bold tabular"
          />
        </div>
        <div className="grid grid-cols-3 gap-2 mt-3">
          {quickAmounts.map((v) => (
            <button
              key={v}
              onClick={() => setAmount(String(v))}
              className={`btn-ghost py-2 text-sm tabular ${amount === String(v) ? 'border-neon-400 text-neon-300' : ''}`}
            >
              {store.currency}{v.toLocaleString('en-IN')}
            </button>
          ))}
        </div>
      </div>

      {/* Methods */}
      <div className="panel p-4">
        <h2 className="font-display font-bold text-base text-white mb-3">Payment Method</h2>
        <div className="grid grid-cols-2 gap-2.5">
          {methods.map((m) => {
            const Icon = m.icon;
            const active = method === m.id;
            return (
              <button
                key={m.id}
                onClick={() => setMethod(m.id)}
                className={`flex items-center gap-3 p-3 rounded-xl border transition-all text-left ${active ? 'border-neon-400 bg-neon-500/10' : 'border-borderline-900 bg-midnight-850 hover:border-borderline-800'}`}
              >
                <div className={`w-10 h-10 rounded-lg bg-slatepanel-800 border border-borderline-900 grid place-items-center ${active ? m.accent : 'text-slate-400'}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-white">{m.label}</p>
                  <p className="text-[11px] text-slate-500">{m.desc}</p>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      <button onClick={deposit} className="btn-primary w-full py-3.5 text-base">
        Deposit {store.currency}{(parseFloat(amount) || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
      </button>

      <div className="flex items-center justify-center gap-2 text-[11px] text-slate-600">
        <ShieldCheck className="w-3.5 h-3.5" /> Secured by 256-bit SSL encryption
      </div>
    </div>
  );
}
