import { useState } from 'react';
import GameAlgosTab from './admin/GameAlgosTab';
import UsersTab from './admin/UsersTab';
import SmtpTab from './admin/SmtpTab';
import HtmlEditorTab from './admin/HtmlEditorTab';
import CurrenciesTab from './admin/CurrenciesTab';
import CrmTab from './admin/CrmTab';
import IntercomTab from './admin/IntercomTab';
import { Cpu, Users, Mail, Code2, Coins, Megaphone, Headphones, ArrowLeft, ShieldCheck } from 'lucide-react';
import type { Route } from '../components/BottomNav';

type Tab = 'algos' | 'users' | 'smtp' | 'html' | 'currencies' | 'crm' | 'intercom';

const tabs: { key: Tab; label: string; icon: typeof Cpu }[] = [
  { key: 'algos', label: 'Game Algos', icon: Cpu },
  { key: 'users', label: 'User Profiles', icon: Users },
  { key: 'smtp', label: 'SMTP Setup', icon: Mail },
  { key: 'html', label: 'HTML Editor', icon: Code2 },
  { key: 'currencies', label: 'Currencies', icon: Coins },
  { key: 'crm', label: 'CRM Campaign', icon: Megaphone },
  { key: 'intercom', label: 'Intercom Chat', icon: Headphones },
];

export default function AdminView({ onNavigate }: { onNavigate: (r: Route) => void }) {
  const [tab, setTab] = useState<Tab>('algos');

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-center gap-2">
        <button onClick={() => onNavigate('home')} className="md:hidden w-9 h-9 rounded-xl bg-slatepanel-800 border border-borderline-900 grid place-items-center">
          <ArrowLeft className="w-5 h-5 text-slate-300" />
        </button>
        <div className="flex-1">
          <h1 className="font-display font-extrabold text-xl text-white flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-neon-300" /> Admin Dashboard
          </h1>
          <p className="text-xs text-slate-500">Master command control</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1.5 overflow-x-auto no-scrollbar pb-1">
        {tabs.map((t) => {
          const Icon = t.icon;
          const active = tab === t.key;
          return (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-sm font-semibold whitespace-nowrap transition-all ${active ? 'bg-gradient-to-br from-neon-400 to-neon-600 text-white shadow-neon-glow' : 'bg-slatepanel-800 border border-borderline-900 text-slate-400 hover:text-white hover:border-borderline-800'}`}
            >
              <Icon className="w-4 h-4" />
              {t.label}
            </button>
          );
        })}
      </div>

      {/* Content */}
      <div>
        {tab === 'algos' && <GameAlgosTab />}
        {tab === 'users' && <UsersTab />}
        {tab === 'smtp' && <SmtpTab />}
        {tab === 'html' && <HtmlEditorTab />}
        {tab === 'currencies' && <CurrenciesTab />}
        {tab === 'crm' && <CrmTab />}
        {tab === 'intercom' && <IntercomTab />}
      </div>
    </div>
  );
}
