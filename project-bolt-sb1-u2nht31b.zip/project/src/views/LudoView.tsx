import { Dice5, Bell, ArrowLeft } from 'lucide-react';
import type { Route } from '../components/BottomNav';

export default function LudoView({ onNavigate }: { onNavigate: (r: Route) => void }) {
  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-center gap-2">
        <button onClick={() => onNavigate('home')} className="md:hidden w-9 h-9 rounded-xl bg-slatepanel-800 border border-borderline-900 grid place-items-center">
          <ArrowLeft className="w-5 h-5 text-slate-300" />
        </button>
        <div>
          <h1 className="font-display font-extrabold text-xl text-white">Ludo</h1>
          <p className="text-xs text-slate-500">Classic board game</p>
        </div>
      </div>

      <div className="panel p-8 text-center">
        <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-emeraldwin-500/20 to-emeraldwin-700/5 border border-emeraldwin-500/40 grid place-items-center mx-auto mb-4">
          <Dice5 className="w-10 h-10 text-emeraldwin-400" />
        </div>
        <h2 className="font-display font-extrabold text-2xl text-white">Coming Soon</h2>
        <p className="text-sm text-slate-400 mt-2 max-w-sm mx-auto">
          Ludo is being crafted with real-time multiplayer, private rooms, and tournament modes. Pre-register to get early access.
        </p>
        <button
          onClick={() => onNavigate('deposit')}
          className="btn-primary mt-5 px-5 py-2.5"
        >
          <Bell className="w-4 h-4" /> Notify Me
        </button>
      </div>
    </div>
  );
}
