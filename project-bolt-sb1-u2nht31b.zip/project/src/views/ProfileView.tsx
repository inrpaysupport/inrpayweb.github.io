import { useState } from 'react';
import { getDeviceToken, getClientIP, security } from '../lib/security';
import { store } from '../lib/store';
import { useBalance } from '../lib/hooks';
import { ArrowLeft, User, Shield, Smartphone, Globe, LogOut, Settings, ChevronRight, ShieldCheck, ShieldAlert } from 'lucide-react';
import type { Route } from '../components/BottomNav';

export default function ProfileView({ onNavigate }: { onNavigate: (r: Route) => void }) {
  const balance = useBalance();
  const [account] = useState('player_' + getDeviceToken().slice(4, 10));
  const deviceToken = getDeviceToken();
  const ip = getClientIP();
  const session = security.register(account);
  const secure = session.ok;

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-center gap-2">
        <button onClick={() => onNavigate('home')} className="md:hidden w-9 h-9 rounded-xl bg-slatepanel-800 border border-borderline-900 grid place-items-center">
          <ArrowLeft className="w-5 h-5 text-slate-300" />
        </button>
        <div>
          <h1 className="font-display font-extrabold text-xl text-white">Profile</h1>
          <p className="text-xs text-slate-500">Account & security</p>
        </div>
      </div>

      {/* Profile card */}
      <div className="panel p-5">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-neon-400 to-neon-600 grid place-items-center shadow-neon-glow">
            <User className="w-8 h-8 text-white" />
          </div>
          <div className="flex-1">
            <h2 className="font-display font-bold text-lg text-white">{account}</h2>
            <p className="text-sm text-emeraldwin-400 tabular font-semibold">{store.currency}{balance.toFixed(2)}</p>
            <div className="flex items-center gap-1.5 mt-1">
              {secure ? (
                <span className="chip bg-emeraldwin-500/15 border border-emeraldwin-500/40 text-emeraldwin-400 text-[10px]">
                  <ShieldCheck className="w-3 h-3" /> Verified
                </span>
              ) : (
                <span className="chip bg-coral-500/15 border border-coral-500/40 text-coral-400 text-[10px]">
                  <ShieldAlert className="w-3 h-3" /> Flagged
                </span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Security / device info */}
      <div className="panel p-4">
        <h3 className="font-display font-bold text-sm text-white mb-3 flex items-center gap-2">
          <Shield className="w-4 h-4 text-neon-300" /> Device & Security
        </h3>
        <div className="space-y-2.5">
          <div className="flex items-center gap-3 p-2.5 rounded-xl bg-midnight-850 border border-borderline-900">
            <Smartphone className="w-4 h-4 text-slate-400" />
            <div className="flex-1 min-w-0">
              <p className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold">Device Token</p>
              <p className="text-xs text-slate-200 font-mono truncate">{deviceToken}</p>
            </div>
          </div>
          <div className="flex items-center gap-3 p-2.5 rounded-xl bg-midnight-850 border border-borderline-900">
            <Globe className="w-4 h-4 text-slate-400" />
            <div className="flex-1 min-w-0">
              <p className="text-[10px] uppercase tracking-wider text-slate-500 font-semibold">Client IP Node</p>
              <p className="text-xs text-slate-200 font-mono">{ip}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Menu */}
      <div className="panel divide-y divide-borderline-900">
        {[
          { label: 'Settings', icon: Settings, route: null as Route | null },
          { label: 'Wallet', icon: ChevronRight, route: 'wallet' as Route },
          { label: 'Admin Dashboard', icon: ChevronRight, route: 'admin' as Route },
        ].map((m) => {
          const Icon = m.icon;
          return (
            <button
              key={m.label}
              onClick={() => m.route && onNavigate(m.route)}
              className="w-full flex items-center gap-3 p-4 hover:bg-slatepanel-800 transition-colors first:rounded-t-2xl last:rounded-b-2xl"
            >
              <Icon className="w-5 h-5 text-slate-400" />
              <span className="flex-1 text-left text-sm font-semibold text-white">{m.label}</span>
              <ChevronRight className="w-4 h-4 text-slate-600" />
            </button>
          );
        })}
      </div>

      <button
        onClick={() => { store.pushNotification({ title: 'Logged out', body: 'Session ended.', kind: 'info' }); onNavigate('home'); }}
        className="btn-coral w-full py-3"
      >
        <LogOut className="w-4 h-4" /> Log Out
      </button>
    </div>
  );
}
