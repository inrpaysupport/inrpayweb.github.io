import { useEffect, useState } from 'react';
import Header from './components/Header';
import BottomNav, { type Route } from './components/BottomNav';
import NotificationDrawer from './components/NotificationDrawer';
import HomeView from './views/HomeView';
import GamesView from './views/GamesView';
import CrashView from './views/CrashView';
import MinesView from './views/MinesView';
import LudoView from './views/LudoView';
import WalletView from './views/WalletView';
import DepositView from './views/DepositView';
import ProfileView from './views/ProfileView';
import AdminView from './views/AdminView';
import { crashEngine } from './lib/crashEngine';
import { security, getDeviceToken } from './lib/security';
import { store } from './lib/store';
import { bus, Topics } from './lib/bus';

export default function App() {
  const [route, setRoute] = useState<Route>('home');
  const [notifOpen, setNotifOpen] = useState(false);

  // Boot: register session + security layer
  useEffect(() => {
    const account = 'player_' + getDeviceToken().slice(4, 10);
    const res = security.register(account);
    if (!res.ok) {
      store.pushNotification({
        title: 'Multi-Account Security Alert',
        body: `Device ${res.session?.deviceToken} already registered to ${res.session?.account}. Connection rejected.`,
        kind: 'alert',
      });
      bus.emit(Topics.SecurityAlert, res);
    }
    // Keep crash engine warm for live feed on home
    crashEngine.start();
    return () => crashEngine.stop();
  }, []);

  const navigate = (r: Route) => {
    setRoute(r);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-midnight-900">
      {/* Ambient background glow */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-40 -left-40 w-96 h-96 rounded-full bg-neon-500/5 blur-3xl" />
        <div className="absolute top-1/3 -right-40 w-96 h-96 rounded-full bg-emeraldwin-500/5 blur-3xl" />
      </div>

      <div className="relative">
        <Header onOpenNotifications={() => setNotifOpen(true)} onOpenWallet={() => navigate('wallet')} />

        <main className="max-w-6xl mx-auto px-4 pt-4 pb-28 md:pb-12">
          {route === 'home' && <HomeView onNavigate={navigate} />}
          {route === 'games' && <GamesView onNavigate={navigate} />}
          {route === 'crash' && <CrashView />}
          {route === 'mines' && <MinesView />}
          {route === 'ludo' && <LudoView onNavigate={navigate} />}
          {route === 'wallet' && <WalletView onNavigate={navigate} />}
          {route === 'deposit' && <DepositView onNavigate={navigate} />}
          {route === 'profile' && <ProfileView onNavigate={navigate} />}
          {route === 'admin' && <AdminView onNavigate={navigate} />}
        </main>

        <BottomNav route={route} onNavigate={navigate} />
      </div>

      <NotificationDrawer open={notifOpen} onClose={() => setNotifOpen(false)} />
    </div>
  );
}
